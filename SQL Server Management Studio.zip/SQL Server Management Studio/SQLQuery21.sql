--1 DIM_CHARGE_CATEG_SQL
CREATE TABLE DIM_CHARGE_CATEG_SQL_IN1542(
Charge_categ_Key	int	   identity(1,1) primary key         ,       
CHARGE_CATEG_ID	int	              NOT NULL  ,         
TENANT_ORG_ID	int               NOT NULL  ,       
CHARGE_CATEG	varchar(50)	      NOT NULL  ,       
CHARGE_CATEG_DESC	varchar(50)	  NOT NULL  ,       
TAX_IND	int	                      NOT NULL,       
VERSION INT
        ) ;	
		
SELECT * FROM DIM_CHARGE_CATEG_SQL_IN1542
 INSERT INTO DIM_CHARGE_CATEG_SQL_IN1542(
 CHARGE_CATEG_ID,TENANT_ORG_ID,CHARGE_CATEG,CHARGE_CATEG_DESC,TAX_IND,VERSION)

 SELECT 
 DISTINCT
 ISNULL(CONVERT(INT,LTRIM(RTRIM(CHARGE_CATEG_ID))),101) AS CHARGE_CATEG_ID ,
 ISNULL(CONVERT(INT,LTRIM(RTRIM(TENANT_ORG_ID))),101)
AS TENANT_ORG_ID,
CASE
when LEN(LTRIM(RTRIM(CHARGE_CATEG)))> 5 then LTRIM(RTRIM(CHARGE_CATEG))
else upper(ltrim(rtrim(charge_categ))) END AS CHARGE_CATEG,
 ltrim(rtrim(charge_categ_desc))  AS CHARGE_CATEG_DESC,
ISNULL(CONVERT(INT,TAX_IND),101) ,1 AS VERSION
FROM [BCMPWMT].[CHARGE_CATEG_LKP]
------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE DIM_CUST_SQL_IN1542(

cust_key	int    identity(1,1) primary key            ,
CUST_ID	int               NOT NULL     ,
TENANT_ORG_ID	int       NOT NULL     ,
CUST_TYPE_ID	int       NOT NULL     ,
NICKNAME	varchar(50)   NOT NULL     ,
SALUTE	varchar(50)       NOT NULL     ,
MIDDLE_NM	varchar(50)   NOT NULL     ,
CUST_TITLE	varchar(50)   NOT NULL     ,
SUFFIX	varchar(50)       NOT NULL     ,
WM_EMPLOYEE_ID	int       NOT NULL     ,
CRE_DT	date              NOT NULL     ,
CRE_USER	varchar(50)   NOT NULL     ,
UPD_TS	datetime          NOT NULL     ,
UPD_USER	varchar(50)   NOT NULL     ,
START_DATE  DATE,
END_DATE DATE,
SIGNUP_TS	datetime      NOT NULL     ,
REALM_ID	varchar(50)   NOT NULL     ,
							   
VALID_CUST_IND	varchar(50) NOT NULL    ,
DELTD_YN	varchar(50)   NOT NULL)    ; 

INSERT INTO DIM_CUST_SQL_in1542(CUST_ID,TENANT_ORG_ID,CUST_TYPE_ID,
NICKNAME,SALUTE,MIDDLE_NM,CUST_TITLE,SUFFIX,WM_EMPLOYEE_ID,
CRE_DT,CRE_USER,UPD_TS,UPD_USER,start_date,end_date,
SIGNUP_TS,REALM_ID,	VALID_CUST_IND,DELTD_YN)

SELECT 
IIF(cust_id LIKE 'NULL' OR cust_id IS NULL ,101,(cast(ltrim(rtrim(cust_id)) as int))) AS CUST_ID,
IIF(TENANT_ORG_ID LIKE 'NULL' OR TENANT_ORG_ID IS NULL,101,(cast(ltrim(rtrim(TENANT_ORG_ID)) as int))) AS TENANT_ORG_ID,
IIF(CUST_TYPE_ID LIKE 'NULL' OR CUST_TYPE_ID IS NULL,101,(cast(ltrim(rtrim(CUST_TYPE_ID)) as int))) AS CUST_TYPE_ID,
iif(nickname like'NULL' OR nickname IS NULL ,'N/A',nickname) NICKNAME,
IIF(salute like'NULL' OR salute  IS NULL,'N/A',SUBSTRING(ltrim(rtrim(salute)),1,4) ),
IIF(ltrim(rtrim(middle_nm)) LIKE 'NULL','N/A',middle_nm),
iif(cust_title like 'null' OR CUST_TITLE IS NULL ,'N/A',(REPLACE(ltrim(rtrim(cust_title)),'#',' ')))cust_title,
IIF(suffix LIKE 'NULL' OR suffix IS NULL ,'N/A',SUBSTRING(ltrim(rtrim(suffix)),2,1))suffix, 

IIF(wm_employee_id LIKE 'NULL' OR wm_employee_id IS NULL ,101,(cast(ltrim(rtrim(wm_employee_id)) as int))) AS wm_employee_id,
IIF(cre_dt LIKE 'NULL' OR cre_dt IS NULL ,'01-01-1990',(cast(ltrim(rtrim(cre_dt)) as DATE))) AS cre_dt,
IIF(CRE_user LIKE 'NULL' OR CRE_user IS NULL ,'N/A',ltrim(rtrim(CRE_user)))CRE_user,
FORMAT(IIF(upd_ts LIKE 'NULL' OR upd_ts IS NULL ,'01-01-1900',(cast(ltrim(rtrim(upd_ts)) as DATETIME))),'MM-dd-yyyy HH:mm:ss') AS upd_ts,
IIF(UPD_USER LIKE 'NULL' OR UPD_USER IS NULL ,'N/A',ltrim(rtrim(UPD_USER))) AS UPD_USER, 
GETDATE() AS START_DATE,NULL AS END_DATE,
format(IIF(signup_ts LIKE 'NULL' OR signup_ts IS NULL ,'01-01-1900',(cast(ltrim(rtrim(signup_ts)) as DATETIME))),'MM-dd-yyyy HH:mm:ss') AS signup_ts,

IIF(realm_id LIKE 'NULL' OR realm_id IS NULL ,'N/A',ltrim(rtrim(realm_id)))realm_id,
IIF(valid_cust_ind LIKE 'NULL' OR valid_cust_ind IS NULL ,'N/A',ltrim(rtrim(valid_cust_ind)))valid_cust_ind,
IIF(DELTD_YN LIKE 'NULL' OR DELTD_YN IS NULL ,'N/A',ltrim(rtrim(DELTD_YN)))DELTD_YN 
FROM
 [BCMPWMT].[CUST]
 ------------------------------------------------------------------------------------------------------------------------------
 CREATE TABLE dim_CUST_ACCT_SQL_IN1542
(
cust_acct_key  int identity(1,1) primary key	NOT NULL	,	
ACCT_ID  bigint  NOT NULL			,
CUST_ID  int  NOT NULL			    ,
TENANT_ORG_ID  int  NOT NULL		,
ACCT_STS_ID  int  NOT NULL			,
ACCT_TYPE_ID  int  NOT NULL			,
EMAIL  varchar(250)  NOT NULL		,
VALID_CUST_IND  INT  NOT NULL		,
CRE_DT  date  NOT NULL			    ,
CRE_USER  varchar(250)  NOT NULL	,	
UPD_TS  datetime  NOT NULL			,
UPD_USER  varchar(250)  NOT NULL	,	
Start_Date  datetime  NOT NULL		,
End_Date  datetime NULL		,
DELTD_YN  char(1)  NOT NULL			
)


INSERT INTO dim_CUST_ACCT_SQL_IN1542


select 
IIF(ACCT_ID    IS NULL OR   ACCT_ID is null,101, cast(ltrim(rtrim(acct_id))as bigint)) as ACCT_ID                          ,
IIF(CUST_ID    IS NULL OR   CUST_ID is null,101,cast(ltrim(rtrim(cust_id))as int))as CUST_ID								 ,
IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID is null,101,cast(ltrim(rtrim(tenant_org_id))as int))as TENANT_ORG_ID		 ,
IIF(ACCT_STS_ID    IS NULL OR   ACCT_STS_ID is null,101,cast(ltrim(rtrim(acct_sts_id))as int))as ACCT_STS_ID				 ,
IIF(ACCT_TYPE_ID    IS NULL OR   ACCT_TYPE_ID is null,101,cast(ltrim(rtrim(acct_type_id))as int))as ACCT_TYPE_ID			 ,
IIF(EMAIL    IS NULL OR   EMAIL is null,'N/A', ltrim(rtrim(email)) )as EMAIL				 ,
IIF(VALID_CUST_IND    IS NULL OR   VALID_CUST_IND is null,101,cast(ltrim(rtrim(valid_cust_ind))as int))as VALID_CUST_IND	 ,
																	
IIF(CRE_DT    IS NULL OR   CRE_DT is null,'01-01-1900',cast(ltrim(rtrim(cre_dt))as date))as CRE_DT						 ,
IIF(CRE_USER    IS NULL OR   CRE_USER is null,'N/A',ltrim(rtrim(cre_user)))as CRE_USER									 ,
IIF(UPD_TS    IS NULL OR   UPD_TS is null,'01-01-1900',cast(ltrim(rtrim(upd_ts))as datetime))as UPD_TS					 ,
IIF(UPD_USER    IS NULL OR   UPD_USER is null,'N/A',ltrim(rtrim(upd_user)))as UPD_USER									 ,
GETDATE() AS START_DATE,
NULL AS END_DATE	,IIF(DELTD_YN    IS NULL OR   DELTD_YN is null,'N/A' ,cast(ltrim(rtrim(deltd_yn))as char(1))) as delt_dt
																
from 
[BCMPWMT].[CUST_ACCT]
------------------------------------------------------------------------------------------------------------------------------
create table dim_cust_address_SQL_IN1542
(
cust_addr_key  int identity(1,1) primary key	NOT NULL			    ,	
ADDR_ID  float NOT NULL				    ,
TENANT_ORG_ID  int  NOT NULL				,
DATA_SRC_ID  int  NOT NULL				    ,
VALID_TS  datetime  NOT NULL				,
VALID_STS  varchar(200)  NOT NULL				,
CITY  nvarchar(255)  NOT NULL				,
MUNICIPALITY  nvarchar(255)  NOT NULL		,
TOWN  nvarchar(255)  NOT NULL				,
VILLAGE  nvarchar(255)  NOT NULL			,
COUNTY  nvarchar(255)  NOT NULL				,
DISTRICT  nvarchar(255)  NOT NULL			,
ZIP_CD  int  NOT NULL				        ,
POSTAL_CD  int  NOT NULL				    ,
ZIP_EXTN  int  NOT NULL				        ,
ADDR_TYPE  nvarchar(255)  NOT NULL			,
AREA  nvarchar(255)  NOT NULL				,
CNTRY_CD  nvarchar(255)  NOT NULL			,
STATE_PRVNCE_TYPE  nvarchar(255)  NOT NULL	,
OWNER_ID  int  NOT NULL				        ,
PARENT_ID  int  NOT NULL				    ,
DELTD_YN  char(1)  NOT NULL				    ,
Start_Date  datetime  NOT NULL				,
End_Date  datetime   NULL				,
CRE_DT  date  NOT NULL				        ,
CRE_USER  nvarchar(255)  NOT NULL			,
UPD_TS  datetime  NOT NULL				    ,
UPD_USER  nvarchar(255)  NOT NULL	)

truncate table dim_cust_address_SQL_IN1542 
select zip_cd from dim_cust_address_SQL_IN1542 
SELECT 
*
from
dim_cust_address_SQL_IN1542 

INSERT INTO dim_cust_address_SQL_IN1542 
SELECT 
IIF(Addr_ID is null,101.00, addr_id)as Addr_ID
,IIF(TENANT_ORG_ID    IS NULL,101,cast(ltrim(rtrim(tenant_org_id))as int))as TENANT_ORG_ID	
,IIF(DATA_SRC_ID    IS NULL,101,cast(ltrim(rtrim(data_src_id))as int))as DATA_SRC_ID			
																
,IIF(VALID_TS  is null or valid_ts like '?','01-01-1900',cast(ltrim(rtrim(valid_ts))as datetime))as VALID_TS		
,IIF(VALID_STS  is null or valid_sts like '?', 'N/A',ltrim(rtrim(valid_sts)))as VALID_STS							
,IIF(CITY    IS NULL ,'N/A',ltrim(rtrim(city)))as CITY										
,IIF(MUNICIPALITY   is null or MUNICIPALITY like '?','N/A',ltrim(rtrim(municipality)))as MUNICIPALITY					
,IIF(TOWN  is null or town like '?','N/A',ltrim(rtrim(town)))as TOWN											
,IIF(VILLAGE is null or village like '?','N/A',ltrim(rtrim(village)))as VILLAGE									
,IIF(COUNTY is null or county like '?','N/A',ltrim(rtrim(county)))as COUNTY										
,IIF(DISTRICT is null or district like '?','N/A',ltrim(rtrim(distRict)))as DISTRICT							
,IIF(ZIP_CD    IS NULL OR    zip_cd like '%[a-z+-]%' ,101,cast(ltrim(rtrim(zip_cd))as int))as ZIP_CD		
,IIF(POSTAL_CD    is null or postal_cd like '?',101,cast(ltrim(rtrim(postal_cd))as int))as POSTAL_CD				
,IIF(ZIP_EXTN    IS NULL OR   ZIP_EXTN like '?',101,cast(ltrim(rtrim(zip_extn))as int))as ZIP_EXTN
,IIF(ADDR_TYPE   is null or addr_type like '?','N/A',ltrim(rtrim(addr_type)))as ADDR_TYPE							
,IIF(AREA    is null or area like '?','N/A',ltrim(rtrim(area)))as AREA											
,IIF(CNTRY_CD  LIKE 'null' or cntry_cd is null or cntry_cd like '?','N/A',ltrim(rtrim(cntry_cd)))as CNTRY_CD							
,IIF(STATE_PRVNCE_TYPE LIKE 'null' or state_prvnce_type like '?','N/A',ltrim(rtrim(state_prvnCe_type)))as STATE_PRVNCE_TYPE
,IIF(OWNER_ID  is null or owner_id like '?',101,cast(ltrim(rtrim(owner_id))as int))as OWNER_ID						
,IIF(PARENT_ID    is null or parent_id like '?',101,cast(ltrim(rtrim(parent_id))as int))as PARENT_ID				
,IIF(DELTD_YN    IS NULL OR   DELTD_YN is null,'N/A' ,cast(ltrim(rtrim(deltd_yn))as char))as DELTD_YN	
,GETDATE() AS START_DATE
,NULL AS END_DATE													
,IIF(CRE_DT    IS NULL OR   CRE_DT is null,'01-01-1900',cast(ltrim(rtrim(cre_dt))as date))as CRE_DT	
,IIF(CRE_USER    IS NULL OR   CRE_USER is null,'N/A',ltrim(rtrim(cre_user)))as CRE_USER				
,IIF(UPD_TS is null or upd_ts like '?','01-01-1900',cast(substring(UPD_TS,1,charindex('.',UPD_TS)-1)as datetime))as UPD_TS					
,IIF(UPD_USER is null or upd_user like '?','N/A',ltrim(rtrim(upd_user)))as UPD_USER									
FROM
[BCMPWMT].[CUST_ADDR]
------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE dim_cust_addr_zone_SQL_IN1542(

addr_zone_id_key  int identity(1,1) primary key	NOT NULL	,
ADDR_ZONE_ID  int  NOT NULL			,
TENANT_ORG_ID  int  NOT NULL		,
DATA_SRC_ID  int  NOT NULL			,
CITY  varchar(50)  NOT NULL			,
POSTAL_CD  varchar(50)  NOT NULL	,
STATE  varchar(50)  NOT NULL		,
DELTD_YN  varchar(50)  NOT NULL		,
CRE_USER  varchar(50)  NOT NULL		,
CRE_DT  date  NOT NULL			    ,
UPD_USER  varchar(50)  NOT NULL		,
UPD_TS  datetime  NOT NULL		)
INSERT INTO dim_cust_addr_zone_SQL_IN1542
SELECT
IIF(ADDR_ZONE_ID    IS NULL OR   ADDR_ZONE_ID is null,101,cast(ltrim(rtrim(addr_zone_id))as int))as ADDR_ZONE_ID          ,
IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID is null,101,cast(ltrim(rtrim(tenant_org_id))as int))as TENANT_ORG_ID		 ,
IIF(DATA_SRC_ID    IS NULL OR   DATA_SRC_ID is null,101,cast(ltrim(rtrim(data_src_id))as int))as DATA_SRC_ID				 ,
IIF(CITY    IS NULL OR   CITY is null,'N/A',ltrim(rtrim(city)))as CITY													 ,
IIF(POSTAL_CD    IS NULL OR   POSTAL_CD is null,'N/A',ltrim(rtrim(postal_cd)))as POSTAL_CD								 ,
IIF(STATE    IS NULL OR   STATE is null,'N/A',ltrim(rtrim(state)))as STATE												 ,
																				 
IIF(DELTD_YN    IS NULL OR   DELTD_YN is null,'N/A',cast(ltrim(rtrim(deltd_yn))as varchar))as DELTD_YN					 ,
IIF(CRE_USER    IS NULL OR   CRE_USER is null,'N/A',ltrim(rtrim(cre_user)))as CRE_USER									 ,
IIF(CRE_DT    IS NULL OR   CRE_DT is null,'01-01-1900',cast(ltrim(rtrim(cre_dt))as date))as CRE_DT						 ,
IIF(UPD_USER    IS NULL OR   UPD_USER is null,'N/A',ltrim(rtrim(upd_user)))as UPD_USER									 ,
IIF(UPD_TS    IS NULL OR   UPD_TS is null,'01-01-1900',cast(ltrim(rtrim(upd_ts))as datetime))as UPD_TS					 
FROM [BCMPWMT].[CUST_ADDR_ZONE]
------------------------------------------------------------------------------------------------------------------------------
create table dim_cust_addr1_sql_IN1542(
cust_aadr1_key  int identity(1,1) primary keY,	
ADDR_ID  bigint  NOT NULL				   ,
TENANT_ORG_ID  int  NOT NULL				,
DATA_SRC_ID  int  NOT NULL				   ,
VALID_TS  nvarchar(255)  NOT NULL			,
VALID_STS  int  NOT NULL				   ,
CITY  nvarchar(255)  NOT NULL				,
MUNICIPALITY  nvarchar(255)  NOT NULL		,
TOWN  nvarchar(255)  NOT NULL				,
VILLAGE  nvarchar(255)  NOT NULL			,
COUNTY  nvarchar(255)  NOT NULL				,
DISTRICT  nvarchar(255)  NOT NULL			,
ZIP_CD  int  NOT NULL				       ,
POSTAL_CD  nvarchar(255)  NOT NULL			,
ZIP_EXTN  nvarchar(255)  NOT NULL			,
ADDR_TYPE  nvarchar(255)  NOT NULL			,
AREA  nvarchar(255)  NOT NULL				,
CNTRY_CD  nvarchar(255)  NOT NULL			,
STATE_PRVNCE_TYPE  nvarchar(255)  NOT NULL	,	
OWNER_ID  int  NOT NULL				       ,
PARENT_ID  int  NOT NULL				   ,
DELTD_YN  nvarchar(255)  NOT NULL			,
CRE_DT  date  NOT NULL				       ,
CRE_USER  nvarchar(255)  NOT NULL			)



insert into dim_cust_addr1_sql_IN1542
select 

IIF(ADDR_ID    IS NULL OR   ADDR_ID='null',101,cast(ltrim(rtrim(addr_id))as bigint))as ADDR_ID
,IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID='null',101,cast(ltrim(rtrim(tenant_org_id))as int))as TENANT_ORG_ID
,IIF(DATA_SRC_ID    IS NULL OR   DATA_SRC_ID='null',101,cast(ltrim(rtrim(data_src_id))as int))as DATA_SRC_ID

,IIF(VALID_TS    IS NULL OR   VALID_TS='null'or valid_ts like '?','N/A',format(convert(date,VALID_TS ),'dd-MMM-yyyy') )as VALID_TS
,IIF(VALID_STS    IS NULL OR   VALID_STS='null' or valid_sts like '?',101,cast(ltrim(rtrim(valid_sts))as int))as VALID_STS
,IIF(CITY    IS NULL OR   CITY='null','N/A',ltrim(rtrim(city)))as CITY
,IIF(MUNICIPALITY    IS NULL OR   MUNICIPALITY='null' or MUNICIPALITY like '?' or (len(MUNICIPALITY)>2 and len(MUNICIPALITY)<8 ),'N/A',( ltrim(rtrim(municipality))))as MUNICIPALITY
,IIF(TOWN    IS NULL OR   TOWN='null' or TOWN like '?','N/A',ltrim(rtrim(town)))as TOWN
,IIF(VILLAGE    IS NULL OR   VILLAGE='null'or  VILLAGE like '?','N/A',ltrim(rtrim(village)))as VILLAGE
,IIF(COUNTY    IS NULL OR   COUNTY='null' or county like '?','N/A',ltrim(rtrim(county)))as COUNTY
,IIF(DISTRICT    IS NULL OR   DISTRICT='null' or district like '?','N/A',ltrim(rtrim(district)))as DISTRICT
,IIF(ZIP_CD    IS NULL OR   ZIP_CD='null',101,cast(ltrim(rtrim(zip_cd))as int))as ZIP_CD
,IIF(POSTAL_CD    IS NULL OR   POSTAL_CD='null' or postal_cd like '?','N/A',ltrim(rtrim(postal_cd)))as POSTAL_CD
,IIF(ZIP_EXTN    IS NULL OR   ZIP_EXTN='null' or zip_extn like '?','N/A',ltrim(rtrim(zip_extn)))as ZIP_EXTN
,IIF(ADDR_TYPE    IS NULL OR   ADDR_TYPE='null','N/A',ltrim(rtrim(addr_type)))as ADDR_TYPE
,IIF(AREA    IS NULL OR   AREA='null' or area like '?','N/A',ltrim(rtrim(area)))as AREA
,IIF(CNTRY_CD    IS NULL OR   CNTRY_CD='null','N/A',ltrim(rtrim(cntry_cd)))as CNTRY_CD
,IIF(STATE_PRVNCE_TYPE    IS NULL OR   STATE_PRVNCE_TYPE='null' or state_prvnce_type='?','N/A',ltrim(rtrim(state_prvnce_type)))as STATE_PRVNCE_TYPE
,IIF(OWNER_ID    IS NULL or owner_id = '?'  OR   OWNER_ID='null',101,cast(ltrim(rtrim(owner_id))as int))as OWNER_ID
,IIF(parent_id like '?' or PARENT_ID    IS NULL OR   PARENT_ID='null',101,cast(ltrim(rtrim(parent_id))as int))as PARENT_ID
,IIF(DELTD_YN    IS NULL OR   DELTD_YN='null','N/A',ltrim(rtrim(deltd_yn)))as DELTD_YN
,IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',cast(ltrim(rtrim(cre_dt))as date))as CRE_DT
,IIF(CRE_USER    IS NULL OR   CRE_USER='null','N/A',ltrim(rtrim(cre_user)))as CRE_USER

from [BCMPWMT].[CUST_ADDR1]
------------------------------------------------------------------------------------------------------------------------------
create table DIM_CUST_EMAIL_SQL_IN1542(

Cust_email_key  int identity(1,1) primary key	NOT NULL	,	
EMAIL_ID  bigint  NOT NULL									,
TENANT_ORG_ID  int  NOT NULL								,
CNTCT_TYPE_ID  int  NOT NULL								,
DATA_SRC_ID  int  NOT NULL									,
DELTD_YN  varchar  NOT NULL									,
CRE_DT  Date  NOT NULL										,
UPD_TS  Date  NOT NULL			
)
select * from DIM_CUST_EMAIL_SQL_IN1542

INSERT INTO DIM_CUST_EMAIL_SQL_IN1542
SELECT 

IIF(EMAIL_ID    IS NULL OR   EMAIL_ID='null',101,cast(ltrim(rtrim(EMAIL_ID)) as bigint))as EMAIL_ID                   ,
IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID='null',101,cast(ltrim(rtrim(Tenant_Org_id)) as int))as TENANT_ORG_ID  ,
IIF(CNTCT_TYPE_ID    IS NULL OR   CNTCT_TYPE_ID='null',101,cast(ltrim(rtrim(cntct_type_id)) as int))as CNTCT_TYPE_ID  ,
IIF(DATA_SRC_ID    IS NULL OR   DATA_SRC_ID='null',101,cast(ltrim(rtrim(Data_src_id)) as int))as DATA_SRC_ID		  ,
IIF(DELTD_YN    IS NULL OR   DELTD_YN='null','N/A' ,cast(ltrim(rtrim(Deltd_yn)) as varchar) )as DELTD_YN					  ,
																											
IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',cast(ltrim(rtrim(Cre_Dt))as Date))as CRE_DT					  ,
IIF(UPD_TS    IS NULL OR   UPD_TS='null','01-01-1900',cast(ltrim(rtrim(Upd_ts))as Date))as UPD_TS					  

FROM [BCMPWMT].[CUST_EMAIL]

SELECT * FROM [BCMPWMT].[CUST_PHONE]
------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE DIM_CUST_PHONE_SQL_IN1542(
Cust_phone_key  int identity(1,1) primary key	NOT NULL,		
PHONE_ID  bigint  NOT NULL			                ,
TENANT_ORG_ID  int  NOT NULL						,
CNTCT_TYPE_ID  bigint  NOT NULL						,
SRC_PHONE_ID  varchar(50)  NOT NULL					,
DATA_SRC_ID  int  NOT NULL							,
AREA_CD  varchar(50)  NOT NULL						,
CNTRY_CD  varchar(50)  NOT NULL						,
EXTN  varchar(50)  NOT NULL							,
CRE_DT  Date  NOT NULL								,
DELTD_YN  varchar(50)  NOT NULL						,
UPD_TS  DateTime  NOT NULL							)

INSERT INTO DIM_CUST_PHONE_SQL_IN1542 
SELECT 

IIF(PHONE_ID    IS NULL OR   PHONE_ID='null',101,CONVERT(BIGINT,(ltrim(rtrim(PHONE_ID)))))as PHONE_ID ,                       
IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID='null',101,cast(ltrim(rtrim(Tenant_Org_id)) as int))as TENANT_ORG_ID   
,IIF(CNTCT_TYPE_ID    IS NULL OR   CNTCT_TYPE_ID='null',101,cast(ltrim(rtrim(cntct_type_id)) as int))as CNTCT_TYPE_ID   
,IIF(SRC_PHONE_ID    IS NULL OR   SRC_PHONE_ID='null','N/A',ltrim(rtrim(Src_phone_id) ))as SRC_PHONE_ID				   
,IIF(DATA_SRC_ID    IS NULL OR   DATA_SRC_ID='null',101,cast(ltrim(rtrim(Data_src_id)) as int))as DATA_SRC_ID		  
,IIF(AREA_CD    IS NULL OR   AREA_CD='null',101,cast(ltrim(rtrim(AREA_CD))as int))as AREA_CD						   
,IIF(CNTRY_CD    IS NULL OR   CNTRY_CD='null','N/A',ltrim(rtrim(CNTRY_CD)))as CNTRY_CD								
,IIF(EXTN    IS NULL OR   EXTN='null','N/A',ltrim(rtrim(EXTN)))as EXTN											


,IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',cast(ltrim(rtrim(Cre_Dt))as Date ))as CRE_DT			
,IIF(DELTD_YN    IS NULL OR   DELTD_YN='null','N/A',cast(ltrim(rtrim(Deltd_yn)) as char)) as DELTD_YN		
,IIF(UPD_TS    IS NULL OR   UPD_TS='null','01-01-1900',cast(ltrim(rtrim(Upd_ts))as Datetime))as UPD_TS			


FROM [BCMPWMT].[CUST_PHONE]

SELECT * FROM [BCMPWMT].[FULFMT_TYPE_LKP]
------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE  Dim_FULFMT_TYPE_LKP_SQL_IN1542(
FULFMT_TYPE_KEY  int identity(1,1) 	NOT NULL,				
FULFMT_TYPE_ID  INT PRIMARY	KEY	,		
FULFMT_TYPE_CD  VARCHAR(50)  NOT NULL		,			
FULFMT_TYPE_DESC  VARCHAR (50) NOT NULL		,			
CRE_DT  DATE  NOT NULL				,	
UPD_TS  Nvarchar(255)  NOT NULL	)		



INSERT INTO Dim_FULFMT_TYPE_LKP_SQL_IN1542 


SELECT 
distinct
IIF(FULFMT_TYPE_ID    IS NULL OR   FULFMT_TYPE_ID='null',101,cast(ltrim(rtrim(FULFMT_TYPE_ID)) AS INT))as FULFMT_TYPE_ID
,IIF(FULFMT_TYPE_CD    IS NULL OR   FULFMT_TYPE_CD='null','N/A',CAST(LTRIM(RTRIM(FULFMT_TYPE_CD))AS VARCHAR(50)))as FULFMT_TYPE_CD
,IIF(FULFMT_TYPE_DESC    IS NULL OR   FULFMT_TYPE_DESC='null', 'N/A',CAST(LTRIM(RTRIM(FULFMT_TYPE_DESC))AS VARCHAR(50)))as FULFMT_TYPE_DESC
,IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',cast(ltrim(rtrim(CRE_DT ))AS DATE))as CRE_DT
,FORMAT(IIF(UPD_TS    IS NULL OR   UPD_TS='null','01-01-1900',cast(ltrim(rtrim(UPD_TS   ))AS DATE)),'MMddyyyy')as UPD_TS
FROM [BCMPWMT].[FULFMT_TYPE_LKP]
------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE Dim_ORDER_STS_MASTER_LKP_SQL_IN1542(
ORDER_STS_MASTER_LKP_KEY   int identity(1,1)	NOT NULL,
ORDER_STS_MASTER_ID  bigint   primary key		,	
ORDER_STS_MASTER_CD  VARCHAR (50) NOT NULL			,	
ORDER_STS_SHORT_DESC  VARCHAR (50) NOT NULL			,	
ORDER_STS_LONG_DESC  VARCHAR (50) NOT NULL			,	
CRE_TS  DATETIME  NOT NULL						,
UPD_TS  DATETIME  NOT NULL						,
		
)

insert into   Dim_ORDER_STS_MASTER_LKP_SQL_IN1542

select 
IIF(ORDER_STS_MASTER_ID    IS NULL OR   ORDER_STS_MASTER_ID='null',101,cast(ltrim(rtrim(ORDER_STS_MASTER_ID ))AS bigint))as ORDER_STS_MASTER_ID
,IIF(ORDER_STS_MASTER_CD    IS NULL OR   ORDER_STS_MASTER_CD='null','N/A' ,LTRIM(RTRIM(ORDER_STS_MASTER_CD)))as ORDER_STS_MASTER_CD
,IIF(ORDER_STS_SHORT_DESC    IS NULL OR   ORDER_STS_SHORT_DESC='null','N/A' ,LTRIM(RTRIM(ORDER_STS_SHORT_DESC)))as ORDER_STS_SHORT_DESC
,IIF(ORDER_STS_LONG_DESC    IS NULL OR   ORDER_STS_LONG_DESC='null','N/A' ,LTRIM(RTRIM(ORDER_STS_LONG_DESC)))as ORDER_STS_LONG_DESC

,IIF(CRE_TS    IS NULL OR   CRE_TS='null' ,'01-01-1900',cast(substring(ltrim(rtrim(cre_ts)),1,charindex(' p',cre_ts))as datetime))as CRE_TS

,IIF(UPD_TS    IS NULL OR   UPD_TS='null','01-01-1900',cast(substring(ltrim(rtrim(upd_ts)),1,charindex(' p',upd_ts))as datetime))as UPD_TS
FROM [BCMPWMT].[ORDER_STS_MASTER_LKP]
------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE dim_rpt_hrchy_SQL_IN1542(                  
rpt_HRCHY_key  int identity(1,1) primary key	NOT NULL
,RPT_HRCHY_ID  FLOAT  NOT NULL							
,SRC_RPT_HRCHY_ID  FLOAT  NOT NULL						
,TENANT_ORG_ID  VARCHAR(255)  NOT NULL					
,RPT_HRCHY_PATH  varchar(200)  NOT NULL					
,DIV_ID  FLOAT  NOT NULL									
,DIV_NM  varchar(200)  NOT NULL							
,SUPER_DEPT_ID  FLOAT  NOT NULL							
,SUPER_DEPT_NM  varchar(200)  NOT NULL					
,DEPT_ID  FLOAT  NOT NULL								
,DEPT_NM  varchar(250)  NOT NULL							
,CATEG_NM  varchar(200)  NOT NULL						
,SUB_CATEG_ID  FLOAT  NOT NULL							
,SUB_CATEG_NM  varchar(200)  NOT NULL							
,ITEM_CATEG_GROUPING_ID  varchar(200)  NOT NULL				
,SRC_CRE_TS  nvarchar(255)  NOT NULL						
,SRC_MODFD_TS  nvarchar(255)  NOT NULL					
,SRC_HRCHY_MODFD_TS  datetime  NOT NULL					
,CATEG_MGR_NM  varchar(200)  NOT NULL					
,BUYER_NM  varchar(200)  NOT NULL						
,EFF_BEGIN_DT  date  NOT NULL							
,EFF_END_DT  date  NOT NULL								
,RPT_HRCHY_ID_PATH  varchar(200)  NOT NULL				
,CATEG_ID  FLOAT  NOT NULL								
,CONSUMABLE_IND  nvarchar(255)  NOT NULL					
,CURR_IND  FLOAT  NOT NULL								
,CRE_DT  date  NOT NULL									
,CRE_USER  nvarchar(255)  NOT NULL						
,UPD_TS  datetime  NOT NULL								
,UPD_USER  nvarchar(255)  NOT NULL		)

drop table 
insert into dim_rpt_hrchy_SQL_IN1542 
select 
IIF(RPT_HRCHY_ID    IS NULL ,101.00 ,cast(RPT_HRCHY_ID as FLOAT))as RPT_HRCHY_ID
,IIF(SRC_RPT_HRCHY_ID    IS NULL ,101.00 ,cast(src_rpt_hrchy_id as FLOAT))as SRC_RPT_HRCHY_ID
,IIF(TENANT_ORG_ID    IS NULL ,'N/A' ,LTRIM(RTRIM((tenant_org_id))))as TENANT_ORG_ID
,IIF(RPT_HRCHY_PATH    IS NULL OR   RPT_HRCHY_PATH='?','N/A' ,cast(ltrim(rtrim(RPT_HRCHY_PATH)) as varchar))as RPT_HRCHY_PATH
,IIF(DIV_ID    IS NULL ,101.00 ,cast(div_id as FLOAT))as DIV_ID
,IIF(DIV_NM    IS NULL OR   DIV_NM='null','N/A' ,cast(ltrim(rtrim(div_nm)) as varchar))as DIV_NM
,IIF(SUPER_DEPT_ID    IS NULL , 'N/A',cast(super_dept_id as int))as SUPER_DEPT_ID
,IIF(SUPER_DEPT_NM    IS NULL OR   SUPER_DEPT_NM='null','N/A' ,cast(ltrim(rtrim(super_dept_nm)) as varchar))as SUPER_DEPT_NM
,IIF(DEPT_ID    IS NULL ,'N/A' ,cast(dept_id as int))as DEPT_ID
,IIF(DEPT_NM    IS NULL OR   DEPT_NM='null','N/A' ,cast(ltrim(rtrim(dept_NM)) as varchar))as DEPT_NM
,IIF(CATEG_NM    IS NULL OR   CATEG_NM='null','N/A' ,cast(ltrim(rtrim(categ_nm)) as varchar))as CATEG_NM
,IIF(SUB_CATEG_ID    IS NULL ,101 ,cast(sub_categ_id as int))as SUB_CATEG_ID
,IIF(SUB_CATEG_NM    IS NULL OR   SUB_CATEG_NM='null','N/A' ,cast(ltrim(rtrim(sub_categ_nm)) as varchar))as SUB_CATEG_NM
,IIF(ITEM_CATEG_GROUPING_ID    IS NULL OR   ITEM_CATEG_GROUPING_ID='null','N/A' ,cast(ltrim(rtrim(item_categ_grouping_id)) as varchar))as ITEM_CATEG_GROUPING_ID
,SRC_CRE_TS as SRC_CRE_TS
,SRC_MODFD_TS as SRC_MODFD_TS
,cast(substring(SRC_HRCHY_MODFD_TS,1,charindex('.',SRC_HRCHY_MODFD_TS)-1)as datetime) as SRC_HRCHY_MODFD_TS
,IIF(CATEG_MGR_NM    IS NULL OR   CATEG_MGR_NM='null','N/A' ,cast(ltrim(rtrim(categ_mgr_nm)) as varchar))as CATEG_MGR_NM
,IIF(BUYER_NM    IS NULL OR   BUYER_NM='null', 'N/A',cast(ltrim(rtrim(buyer_nm)) as varchar))as BUYER_NM
,IIF(EFF_BEGIN_DT    IS NULL or EFF_BEGIN_DT like '%[0-9]%','01-01-1900',cast(eff_begin_dt as date))as EFF_BEGIN_DT
,IIF(EFF_END_DT    IS NULL OR   EFF_END_DT='?','01-01-1900',cast(eff_end_dt as date))as EFF_END_DT
,IIF(RPT_HRCHY_ID_PATH is null or RPT_HRCHY_ID_PATH ='?'   ,'N/A' ,cast(ltrim(rtrim(rpt_hrchy_id_path)) as varchar))as RPT_HRCHY_ID_PATH

,IIF(CATEG_ID    IS NULL ,101.00 ,cast(categ_id as float))as CATEG_ID
,IIF(CONSUMABLE_IND like '[01? ]' ,101,cast(ltrim(rtrim(consumable_ind))as INT))as CONSUMABLE_IND
,IIF(CURR_IND   like'[01?]',101.00 ,cast(ltrim(rtrim(CURR_IND))as FLOAT))as CURR_IND
,IIF(CRE_DT IS NULL   or  CRE_DT like '%[0-9]%','01-01-1900',cast(ltrim(rtrim(cre_dt))as date))as CRE_DT
,CRE_USER as CRE_USER
,IIF(UPD_TS    IS NULL OR   UPD_TS='null','01-01-1900',cast(substring(UPD_TS,1,charindex('.',UPD_TS)-1)as datetime))as UPD_TS
,upd_user as upd_user
from 
[BCMPWMT].[RPT_HRCHY]


------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE DIM_ORG_BUSINESS_UNIT_SQL_IN1542(              
ORG_ID  varchar(50)  NOT NULL	                    ,       			
SRC_ORG_CD  varchar(50)  NOT NULL					,
ORG_TYPE_ID  INT  NOT NULL						,
ORG_NM  varchar(150)  NOT NULL						,
PARENT_ORG_ID  varchar(50)  NOT NULL				,
PARENT_ORG_NM  varchar(250)  NOT NULL				,
WM_RDC_NUM  varchar(50)  NOT NULL					,
WM_STORE_NUM  varchar(50)  NOT NULL					,
WM_DSTRBTR_NO  varchar(50)  NOT NULL				,
WH_IND  bigint  NOT NULL						,
DSV_IND  bigint  NOT NULL						,
ACTV_IND  bigint  NOT NULL						,
EFF_BEGIN_DT  DATE  NOT NULL					,
EFF_END_DT  DATE  NOT NULL						,
CRE_DT  DATE  NOT NULL							,
Is_Valid_Flag  varchar(50)  NOT NULl,
UPD_TS  DATETIME  NOT null,

ORG_BUSINESS_UNIT_KEY  	int identity(1,1) 	NOT NULL
											
)

insert into DIM_ORG_BUSINESS_UNIT_SQL_IN1542 
select 
IIF(ORG_ID    IS NULL OR   ORG_ID='null','N/A' ,LTRIM(RTRIM(ORG_ID)))as ORG_ID
,IIF(SRC_ORG_CD    IS NULL OR   SRC_ORG_CD='null','N/A' ,LTRIM(RTRIM(SRC_ORG_CD)))as SRC_ORG_CD
,IIF(ORG_TYPE_ID    IS NULL OR   ORG_TYPE_ID='null',101,cast(ltrim(rtrim(ORG_TYPE_ID ))AS INT))as ORG_TYPE_ID
,IIF(ORG_NM    IS NULL OR   ORG_NM='null','N/A' ,LTRIM(RTRIM(ORG_NM)))as ORG_NM
,IIF(PARENT_ORG_ID    IS NULL OR   PARENT_ORG_ID='null', 'N/A',LTRIM(RTRIM(PARENT_ORG_ID)))as PARENT_ORG_ID
,IIF(PARENT_ORG_NM    IS NULL OR   PARENT_ORG_NM='null', 'N/A',LTRIM(RTRIM(PARENT_ORG_NM)))as PARENT_ORG_NM
,IIF(WM_RDC_NUM    IS NULL OR   WM_RDC_NUM='null','N/A' ,LTRIM(RTRIM(WM_RDC_NUM)))as WM_RDC_NUM
,IIF(WM_STORE_NUM    IS NULL OR   WM_STORE_NUM='null','N/A' ,LTRIM(RTRIM(WM_STORE_NUM)))as WM_STORE_NUM
,IIF(WM_DSTRBTR_NO    IS NULL OR   WM_DSTRBTR_NO='null', 'N/A',LTRIM(RTRIM(WM_DSTRBTR_NO)))as WM_DSTRBTR_NO
,IIF(WH_IND    IS NULL OR   WH_IND='null',101,cast(ltrim(rtrim(wh_ind))AS bigint))as WH_IND
,IIF(DSV_IND    IS NULL OR   DSV_IND='null',101,cast(ltrim(rtrim(dsv_ind))AS bigint))as DSV_IND
,IIF(ACTV_IND    IS NULL OR   ACTV_IND='null',101,cast(ltrim(rtrim(actv_ind))AS bigint))as ACTV_IND
,IIF(EFF_BEGIN_DT    IS NULL OR   EFF_BEGIN_DT='null','01-01-1900',CONVERT(DATE,LTRIM(RTRIM(EFF_BEGIN_DT))))as EFF_BEGIN_DT
,IIF(EFF_END_DT    IS NULL OR   EFF_END_DT='null','01-01-1900',CONVERT(DATE,LTRIM(RTRIM(EFF_END_DT))))as EFF_END_DT
,IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',CONVERT(DATE,LTRIM(RTRIM(CRE_DT))))as CRE_DT
,1 AS Is_Valid_Flag
,IIF(UPD_TS    IS NULL OR   UPD_TS='null','01-01-1900',CONVERT(DATE,LTRIM(RTRIM(UPD_TS))))as UPD_TS

from [BCMPWMT].[ORG_BUSINESS_UNIT]

------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE 
Dim_ORG_TYPE_LKP_SQL_IN1542(
ORG_TYPE_ID  INT  NOT NULL				,
ORG_TYPE_CD  VARCHAR(50) NOT NULL			,	
ORG_TYPE_DESC  VARCHAR(50)  NOT NULL		,		
ORG_TYPE_NM  VARCHAR(50)  NOT NULL			,	
PARENT_ORG_TYPE_NM  VARCHAR(50)  NOT NULL	,			
PARENT_ORG_TYPE_CD  VARCHAR(50)  NOT NULL	,			
CRE_DT  DATE  NOT NULL					,
CRE_USER  VARCHAR(50)  NOT NULL				,
ORG_TYPE_LKP_KEY  int identity(1,1) primary key	NOT NULL,
P1 VARCHAR(250) NULL,
P2 VARCHAR(250) NULL
)

SELECT * FROM [BCMPWMT].[ORG_TYPE_LKP]

INSERT INTO Dim_ORG_TYPE_LKP_SQL_IN1542
SELECT
IIF(ORG_TYPE_ID    IS NULL OR   ORG_TYPE_ID='null',101,CONVERT(INT,LTRIM(RTRIM(ORG_TYPE_ID))))as ORG_TYPE_ID
,IIF(ORG_TYPE_CD    IS NULL OR   ORG_TYPE_CD='null','N/A' ,LTRIM(RTRIM(ORG_TYPE_CD)))as ORG_TYPE_CD
,IIF(ORG_TYPE_DESC    IS NULL OR   ORG_TYPE_DESC='null','N/A' ,LTRIM(RTRIM(ORG_TYPE_DESC)))as ORG_TYPE_DESC
,IIF(ORG_TYPE_NM    IS NULL OR   ORG_TYPE_NM='null','N/A' ,LTRIM(RTRIM(ORG_TYPE_NM)))as ORG_TYPE_NM
,IIF(PARENT_ORG_TYPE_NM    IS NULL OR   PARENT_ORG_TYPE_NM='null','N/A' ,LTRIM(RTRIM(PARENT_ORG_TYPE_NM)))as PARENT_ORG_TYPE_NM
,IIF(PARENT_ORG_TYPE_CD    IS NULL OR   PARENT_ORG_TYPE_CD='null','N/A' ,LTRIM(RTRIM(PARENT_ORG_TYPE_CD)))as PARENT_ORG_TYPE_CD
,IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',CONVERT(DATE,LTRIM(RTRIM(CRE_DT))))as CRE_DT
,IIF(CRE_USER    IS NULL OR   CRE_USER='null','N/A' ,LTRIM(RTRIM(CRE_USER)))as CRE_USER
,NULL AS P1,NULL AS P2
FROM [BCMPWMT].[ORG_TYPE_LKP]
------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE
dim_prod_SQL_IN1542(
prod_key   int identity(1,1) primary key	NOT NULL	,		
CATLG_ITEM_ID  integer  NOT NULL						,
PRMRY_DSTRBTR_NM  varchar(200)  NOT NULL						,
PRMRY_VEND_NUM  integer  NOT NULL						,
SRC_IMS_CRE_TS  varchar(50)  NOT NULL						,
SRC_IMS_MODFD_TS  varchar(50)  NOT NULL						,
VEND_PACK_QTY  integer  NOT NULL						,
WHSE_PACK_QTY  integer  NOT NULL						,
CURR_PRICE_MODFD_TS  datetime  NOT NULL					,
AMT_ITEM_COST  decimal(19,6)  NOT NULL						,
AMT_BASE_ITEM_PRICE  decimal(19,6)  NOT NULL					,
AMT_BASE_SUGG_PRICE  decimal(19,6)  NOT NULL					,
AMT_SUGG_PRICE  decimal(19,6)  NOT NULL						,
MIN_ITEM_COST  decimal(19,6)  NOT NULL						,
ORIG_PRICE  decimal(19,6)  NOT NULL							,
ORIG_ITEM_PRICE  decimal(19,6)  NOT NULL						,
PROD_NM  varchar (200) NOT NULL								,
PROD_HT  decimal(19,6)  NOT NULL								,
PROD_WT  decimal(19,6)  NOT NULL								,
PROD_LEN  decimal(19,6)  NOT NULL								,
PROD_WDTH  decimal(19,6)  NOT NULL							,
CRE_DT  date  NOT NULL									,
CRE_USER  varchar(50)  NOT NULL				,
UPD_TS  datetime  NOT NULL				,
UPD_USER  varchar(50)  NOT NULL				
)


SELECT * FROM [BCMPWMT].[PROD]

INSERT INTO dim_prod_SQL_IN1542 

SELECT 
IIF(CATLG_ITEM_ID    IS NULL OR   CATLG_ITEM_ID='null', 101,cast(ltrim(rtrim(CATLG_ITEM_ID)) as int))as CATLG_ITEM_ID
,IIF(PRMRY_DSTRBTR_NM    IS NULL OR   PRMRY_DSTRBTR_NM='null','N/A' ,ltrim(rtrim(PRMRY_DSTRBTR_NM)))as PRMRY_DSTRBTR_NM
,IIF(PRMRY_VEND_NUM    IS NULL OR   PRMRY_VEND_NUM='null',101 ,CAST(ltrim(rtrim(PRMRY_VEND_NUM))AS INT))as PRMRY_VEND_NUM
,IIF(SRC_IMS_CRE_TS    IS NULL OR   SRC_IMS_CRE_TS='null','N/A', ltrim(rtrim(SRC_IMS_CRE_TS )))as SRC_IMS_CRE_TS
,IIF(SRC_IMS_MODFD_TS    IS NULL OR   SRC_IMS_MODFD_TS='null','N/A',ltrim(rtrim(SRC_IMS_MODFD_TS )) )as SRC_IMS_MODFD_TS
,IIF(VEND_PACK_QTY    IS NULL OR   VEND_PACK_QTY='null',101 ,cast(ltrim(rtrim(VEND_PACK_QTY)) as int))as VEND_PACK_QTY
,IIF(WHSE_PACK_QTY    IS NULL OR   WHSE_PACK_QTY='null',101 ,cast(ltrim(rtrim(WHSE_PACK_QTY)) as int))as WHSE_PACK_QTY
,IIF(CURR_PRICE_MODFD_TS    IS NULL OR   CURR_PRICE_MODFD_TS='null','01-01-1900',cast(ltrim(rtrim(CURR_PRICE_MODFD_TS))as datetime))as CURR_PRICE_MODFD_TS
,IIF(AMT_ITEM_COST    IS NULL OR   AMT_ITEM_COST='null', 101.00,cast(ltrim(rtrim(AMT_ITEM_COST))as decimal))as AMT_ITEM_COST
,IIF(AMT_BASE_ITEM_PRICE    IS NULL OR   AMT_BASE_ITEM_PRICE='null',101.00 ,cast(ltrim(rtrim(AMT_BASE_ITEM_PRICE))as decimal))as AMT_BASE_ITEM_PRICE
,IIF(AMT_BASE_SUGG_PRICE    IS NULL OR   AMT_BASE_SUGG_PRICE='null',101.00 ,cast(ltrim(rtrim(AMT_BASE_SUGG_PRICE))as decimal))as AMT_BASE_SUGG_PRICE
,IIF(AMT_SUGG_PRICE    IS NULL OR   AMT_SUGG_PRICE='null',101.00 ,cast(ltrim(rtrim(AMT_SUGG_PRICE))as decimal))as AMT_SUGG_PRICE
,IIF(MIN_ITEM_COST    IS NULL OR   MIN_ITEM_COST='null',101.00 ,cast(ltrim(rtrim(MIN_ITEM_COST))as decimal))as MIN_ITEM_COST
,IIF(ORIG_PRICE    IS NULL OR   ORIG_PRICE='null',101.00 ,cast(ltrim(rtrim(ORIG_PRICE))as decimal))as ORIG_PRICE
,IIF(ORIG_ITEM_PRICE    IS NULL OR   ORIG_ITEM_PRICE='null',101.00 ,cast(ltrim(rtrim(ORIG_ITEM_PRICE))as DECIMAL))as ORIG_ITEM_PRICE
,IIF(PROD_NM    IS NULL OR   PROD_NM='null','N/A' ,LTRIM(RTRIM(PROD_NM)))as PROD_NM
,IIF(PROD_HT    IS NULL OR   PROD_HT='null' or PROD_HT like '%[A-Z0-9]%', 101.00,cast(ltrim(rtrim(prod_ht))as FLOAT))as PROD_HT
,IIF(PROD_WT    IS NULL OR   PROD_WT='null',101.00 ,cast(ltrim(rtrim(prod_wt))as decimal))as PROD_WT
,IIF(PROD_LEN    IS NULL OR   PROD_LEN='null',101.00 ,cast(ltrim(rtrim(prod_len))as decimal))as PROD_LEN
,IIF(PROD_WDTH    IS NULL OR   PROD_WDTH='null',101.00 ,cast(ltrim(rtrim(prod_wdth))as decimal))as PROD_WDTH
,IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',cast(ltrim(rtrim(cre_dt))as date))as CRE_DT
,IIF(CRE_USER    IS NULL OR   CRE_USER='null','N/A' ,ltrim(rtrim(cre_user)))as CRE_USER
,IIF(UPD_TS    IS NULL OR   UPD_TS='null'OR UPD_TS like '%[A-Z0-9]%','01-01-1900',cast(ltrim(rtrim(upd_ts))as datetime))as UPD_TS
,IIF(UPD_USER    IS NULL OR   UPD_USER='NULL','N/A',(ltrim(rtrim(UPD_USER))))as UPD_USER
FROM [BCMPWMT].[PROD]

------------------------------------------------------------------------------------------------------------------------------
create table dim_RSN_LKP_sql_IN1542(
rsn_key   int identity(1,1) primary key	NOT NULL  ,
RSN_ID  integer  NOT NULL					  ,
TENANT_ORG_ID  integer  NOT NULL				,
DATA_SRC_ID  integer  NOT NULL				  ,
RSN_TYPE_ID  integer  NOT NULL				  ,
RSN_CD  integer  NOT NULL					  ,
SRC_RSN_ID  integer  NOT NULL				  ,
RSN_DESC  varchar(200)  NOT NULL				,
RSN_LONG_DESC  varchar(200)  NOT NULL			,	
CRE_TS  datetime  NOT NULL					  ,
CRE_USER  varchar(50)  NOT NULL				  ,
UPD_TS  datetime  NOT NULL					  ,
UPD_USER  varchar(50)  NOT NULL				  )

insert  into dim_RSN_LKP_sql_IN1542 
select 

IIF(RSN_ID    IS NULL OR   RSN_ID='null', 101,cast(ltrim(rtrim(rsn_id))as INT))as RSN_ID
,IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID='null',101 ,cast(ltrim(rtrim(tenant_org_id))as INT))as TENANT_ORG_ID
,IIF(DATA_SRC_ID    IS NULL OR   DATA_SRC_ID='null',101 ,cast(ltrim(rtrim(data_src_id))as INT))as DATA_SRC_ID
,IIF(RSN_TYPE_ID    IS NULL OR   RSN_TYPE_ID='null',101 ,cast(ltrim(rtrim(rsn_type_id))as INT))as RSN_TYPE_ID
,IIF(RSN_CD    IS NULL OR   RSN_CD='null'or rsn_cd like '%[a-zA-Z]%',101 ,cast(ltrim(rtrim(rsn_cd))as int))as RSN_CD
,IIF(SRC_RSN_ID    IS NULL OR   SRC_RSN_ID='null',101 ,cast(ltrim(rtrim(src_rsn_id))as INT))as SRC_RSN_ID
,IIF(RSN_DESC    IS NULL OR   RSN_DESC='null','N/A' ,(ltrim(rtrim(rsn_desc))))as RSN_DESC
,IIF(RSN_LONG_DESC    IS NULL OR   RSN_LONG_DESC='null','N/A' ,ltrim(rtrim(rsn_long_desc)))as RSN_LONG_DESC
,IIF(CRE_TS    IS NULL OR   CRE_TS='null','01-01-1900',cast(ltrim(rtrim(cre_ts))as datetime))as CRE_TS
,CRE_USER as CRE_USER
,IIF(UPD_TS    IS NULL OR   UPD_TS='null','01-01-1900',cast(ltrim(rtrim(upd_ts))as datetime))as UPD_TS
,UPD_USER AS UPD_USER

from 
[BCMPWMT].[RSN_LKP]

select * from [BCMPWMT].[RSN_TYPE_LKP]
------------------------------------------------------------------------------------------------------------------------------
create table Dim_RSN_TYPE_LKP_sql_in1542(
RSN_TYPE_ID  INT  NOT NULL			,
RSN_TYPE_CD  varchar(50)  NOT NULL		,	
RSN_TYPE_DESC  varchar(200)  NOT NULL	,		
CRE_TS  datetime  NOT NULL			,
CRE_USER  varchar(50)  NOT NULL			,
RSN_TYPE_LKP_KEY  int identity(1,1) primary key	NOT NULL)



TRUNCATE TABLE Dim_RSN_TYPE_LKP_sql_in154

insert into Dim_RSN_TYPE_LKP_sql_in1542
select 
IIF(RSN_TYPE_ID    IS NULL OR   RSN_TYPE_ID='null',101,CONVERT(INT,LTRIM(RSN_TYPE_ID)))as RSN_TYPE_ID
,IIF(RSN_TYPE_CD    IS NULL OR   RSN_TYPE_CD='null','N/A' ,LTRIM(RTRIM(RSN_TYPE_CD)))as RSN_TYPE_CD
,IIF(RSN_TYPE_DESC    IS NULL OR   RSN_TYPE_DESC='null','N/A' ,LTRIM(RTRIM(RSN_TYPE_DESC)))as RSN_TYPE_DESC
,IIF(CRE_TS    IS NULL OR   CRE_TS='null','01-01-1900',CONVERT(DATETIME,(LTRIM(CRE_TS))))as CRE_TS
,IIF(CRE_USER    IS NULL OR   CRE_USER='null','N/A' ,LTRIM(RTRIM(CRE_USER)))as CRE_USER
from [BCMPWMT].[RSN_TYPE_LKP]

SELECT
 * FROM Dim_RSN_TYPE_LKP_sql_in1542
 ------------------------------------------------------------------------------------------------------------------------------
 create table DIM_STS_LKP_sql_IN1542(
STS_LKP_KEY   int identity(1,1) primary key	 ,
STS_ID  INT  NULL				,
STS_MASTER_ID  INT   NULL		,	
TENANT_ORG_ID  INT  NULL		,	
DATA_SRC_ID  INT NULL			,
STS_CD  VARCHAR(50)  NULL			,
SRC_STS_ID  INT   NULL			,
STS_DESC  VARCHAR(50)  NULL			,
STS_LONG_DESC  VARCHAR(200)  NULL	,		
CRE_TS   VARCHAR(50)   NULL			,
UPD_TS   VARCHAR(50)   NULL	)


INSERT INTO DIM_STS_LKP_sql_IN1542
SELECT 
IIF(STS_ID    IS NULL OR   STS_ID='null',101,CONVERT(INT,LTRIM(RTRIM(STS_ID))))as STS_ID
,IIF(STS_MASTER_ID    IS NULL OR   STS_MASTER_ID='null',101,CONVERT(INT,LTRIM(RTRIM(STS_MASTER_ID))))as STS_MASTER_ID
,IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(TENANT_ORG_ID))))as TENANT_ORG_ID
,IIF(DATA_SRC_ID    IS NULL OR   DATA_SRC_ID='null',101,CONVERT(INT,LTRIM(RTRIM(DATA_SRC_ID))))as DATA_SRC_ID
,IIF(STS_CD    IS NULL OR   STS_CD='null','N/A' ,LTRIM(RTRIM(STS_CD)))as STS_CD
,IIF(SRC_STS_ID    IS NULL OR   SRC_STS_ID='null',101,CONVERT(INT,LTRIM(RTRIM(SRC_STS_ID))))as SRC_STS_ID
,IIF(STS_DESC    IS NULL OR   STS_DESC='null','N/A' ,LTRIM(RTRIM(STS_DESC)))as STS_DESC
,IIF(STS_LONG_DESC    IS NULL OR   STS_LONG_DESC='null','N/A' ,LTRIM(RTRIM(STS_LONG_DESC)))as STS_LONG_DESC
,IIF(CRE_TS    IS NULL OR   CRE_TS='null', '01-01-1900',CONCAT(DATEPART(QQ, CRE_TS),'-',DATEPART(YEAR,CRE_TS)))as CRE_TS
,IIF(UPD_TS    IS NULL OR   UPD_TS ='null', '01-01-1900',CONCAT(DATEPART(QQ, UPD_TS ),'-',DATEPART(YEAR,UPD_TS )))as UPD_TS 
FROM [BCMPWMT].[STS_LKP]
-----------------------------------------------------------------------------------------------------------
select * from dim_day_sql_in1542

SELECT * FROM [BCMPWMT].[ORDER_LINE_CHRG]
SELECT * FROM DIM_CHARGE_CATEG_SQL_IN1542

CREATE TABLE FACT_ORDER_LINE_CHRG_IN1542(

SALES_ORDER_NUM	bigint  not null,
SALES_ORDER_LINE_NUM	INT not null,
TENANT_ORG_ID	INT not null,
CHARGE_CATEG_ID	INT not null,
CHRG_CATEG_MAP_ID	INT not null,
CHARGE_NM	VARCHAR(50) not null,
CHARGE_AMT	DECIMAL(19,6) not null,
CHRG_CRE_DT	DATETIME not null,
CHRG_QTY	INT not null,
CHRG_CRE_DT_KEY	INT not null,
charge_categ_key	INT not null);

drop table FACT_ORDER_LINE_CHRG_IN1542
DIM_CHARGE_CATEG_SQL_IN1542
 dim_day_sql_in1542

 insert into FACT_ORDER_LINE_CHRG_IN1542 
 select 

 IIF(o.SALES_ORDER_NUM    IS NULL OR   o.SALES_ORDER_NUM='null',101,convert(bigint,LTRIM(RTRIM(o.SALES_ORDER_NUM))))as SALES_ORDER_NUM
,IIF(o.SALES_ORDER_LINE_NUM    IS NULL OR   o.SALES_ORDER_LINE_NUM='null',101,CONVERT(INT,ltrim(rtrim(o.SALES_ORDER_LINE_NUM))))as SALES_ORDER_LINE_NUM
,IIF(o.TENANT_ORG_ID    IS NULL OR   o.TENANT_ORG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(o.TENANT_ORG_ID))))as TENANT_ORG_ID
,IIF(o.CHARGE_CATEG_ID    IS NULL OR   o.CHARGE_CATEG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(o.CHARGE_CATEG_ID))))as CHARGE_CATEG_ID
,IIF(o.CHRG_CATEG_MAP_ID    IS NULL OR   o.CHRG_CATEG_MAP_ID='null',101,CONVERT(INT,LTRIM(RTRIM(o.CHRG_CATEG_MAP_ID))))as CHRG_CATEG_MAP_ID
,IIF(O.CHARGE_NM    IS NULL OR   O.CHARGE_NM='null','N/A' ,LTRIM(RTRIM(O.CHARGE_NM)))as CHARGE_NM
,IIF(O.CHARGE_AMT    IS NULL OR   O.CHARGE_AMT='null',101 ,CONVERT(DECIMAL(19,6),LTRIM(RTRIM(O.CHaRGe_AMT))))as CHARGE_AMT
,IIF(O.CHRG_CRE_DT    IS NULL OR   O.CHRG_CRE_DT='null','01-01-1900',CONVERT(DATETIME,LTRIM(RTRIM(O.CHRG_CRE_DT))))as CHRG_CRE_DT
,IIF(O.CHRG_QTY    IS NULL OR   O.CHRG_QTY='null',101,CONVERT(INT,LTRIM(RTRIM(O.CHRG_QTY))))as CHRG_QTY
,D.DAY_KEY AS DCHRG_CRE_DT_KEY 
,C.charge_categ_key AS charge_categ_key
from [BCMPWMT].[ORDER_LINE_CHRG] o left join  dim_day_sql_in1542 d
on iif(o.CHRG_CRE_DT is null or  o.CHRG_CRE_DT is not null ,'01-01-1990',format(convert(datetime,o.CHRG_CRE_DT),'yyyy-MM-dd'))=d.date_id
left join DIM_CHARGE_CATEG_SQL_IN1542 c
on C.CHARGE_CATEG_ID=IIF(O.CHARGE_CATEG_ID IS NULL OR O.CHARGE_CATEG_ID ='NULL',101 ,CONVERT(INT,LTRIM(RTRIM(O.CHARGE_CATEG_ID))))

------------------------------------------------------------------------------------------------------------
CREATE TABLE FACT_ORDER_LINE_CHRG_IN1542(

SALES_ORDER_NUM	bigint  not null,
SALES_ORDER_LINE_NUM	INT not null,
TENANT_ORG_ID	INT not null,
CHARGE_CATEG_ID	INT not null,
CHRG_CATEG_MAP_ID	INT not null,
CHARGE_NM	VARCHAR(50) not null,
CHARGE_AMT	DECIMAL(19,6) not null,
CHRG_CRE_DT	DATETIME not null,
CHRG_QTY	INT not null,
CHRG_CRE_DT_KEY	INT not null,
charge_categ_key	INT not null);

drop table FACT_ORDER_LINE_CHRG_IN1542
DIM_CHARGE_CATEG_SQL_IN1542
 dim_day_sql_in1542

 insert into FACT_ORDER_LINE_CHRG_IN1542 
 select 

 IIF(o.SALES_ORDER_NUM    IS NULL OR   o.SALES_ORDER_NUM='null',101,convert(bigint,LTRIM(RTRIM(o.SALES_ORDER_NUM))))as SALES_ORDER_NUM
,IIF(o.SALES_ORDER_LINE_NUM    IS NULL OR   o.SALES_ORDER_LINE_NUM='null',101,CONVERT(INT,ltrim(rtrim(o.SALES_ORDER_LINE_NUM))))as SALES_ORDER_LINE_NUM
,IIF(o.TENANT_ORG_ID    IS NULL OR   o.TENANT_ORG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(o.TENANT_ORG_ID))))as TENANT_ORG_ID
,IIF(o.CHARGE_CATEG_ID    IS NULL OR   o.CHARGE_CATEG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(o.CHARGE_CATEG_ID))))as CHARGE_CATEG_ID
,IIF(o.CHRG_CATEG_MAP_ID    IS NULL OR   o.CHRG_CATEG_MAP_ID='null',101,CONVERT(INT,LTRIM(RTRIM(o.CHRG_CATEG_MAP_ID))))as CHRG_CATEG_MAP_ID
,IIF(O.CHARGE_NM    IS NULL OR   O.CHARGE_NM='null','N/A' ,LTRIM(RTRIM(O.CHARGE_NM)))as CHARGE_NM
,IIF(O.CHARGE_AMT    IS NULL OR   O.CHARGE_AMT='null',101 ,CONVERT(DECIMAL(19,6),LTRIM(RTRIM(O.CHaRGe_AMT))))as CHARGE_AMT
,IIF(O.CHRG_CRE_DT    IS NULL OR   O.CHRG_CRE_DT='null','01-01-1900',CONVERT(DATETIME,LTRIM(RTRIM(O.CHRG_CRE_DT))))as CHRG_CRE_DT
,IIF(O.CHRG_QTY    IS NULL OR   O.CHRG_QTY='null',101,CONVERT(INT,LTRIM(RTRIM(O.CHRG_QTY))))as CHRG_QTY
,D.DAY_KEY AS CHRG_CRE_DT_KEY 
,C.charge_categ_key AS charge_categ_key
from [BCMPWMT].[ORDER_LINE_CHRG] o left join  dim_day_sql_in1542 d
on iif(o.CHRG_CRE_DT is null or  o.CHRG_CRE_DT is not null ,'01-01-1990',format(convert(datetime,o.CHRG_CRE_DT),'yyyy-MM-dd'))=d.date_id
left join DIM_CHARGE_CATEG_SQL_IN1542 c
on C.CHARGE_CATEG_ID=IIF(O.CHARGE_CATEG_ID IS NULL OR O.CHARGE_CATEG_ID ='NULL',101 ,CONVERT(INT,LTRIM(RTRIM(O.CHARGE_CATEG_ID))))
--------------------------------------------------------------------------
create table fact_sales_order_IN1542(
SALES_ORDER_NUM	 BIGINT      PRIMARY KEY    ,

TENANT_ORG_ID	INT                    NOT NULL  ,
ORDER_REL_TS	DATETIME               NOT NULL  ,
ORDER_REL_DT	DATE                   NOT NULL  ,
ORDER_PLACED_TS	DATETIME               NOT NULL  ,
ORDER_PLACED_DT	DATE                   NOT NULL  ,
TOT_AMT	float                          NOT NULL  ,
TAX_AMT	float                          NOT NULL  ,
CURR_STS_ID	INT                        NOT NULL  ,
BILL_TO_ADDR_ID	varchar(50)            NOT NULL  ,
BILL_TO_CUST_ID	varchar(50)            NOT NULL  ,
CUST_CNTCT_ID	varchar(50)            NOT NULL  ,
GUEST_ORDER_IND	int                    NOT NULL  ,
CORP_ORDER_IND	int                    NOT NULL  ,
DEVICE_TYPE	varchar(50)                NOT NULL  ,
IP_ADDR	varchar(50)                    NOT NULL  ,
FRAUD_CHECK_REQD_IND	int            NOT NULL  ,
ORIG_SALES_ORDER_NUM	varchar(50)    NOT NULL  ,
HOLD_FLAG	int                        NOT NULL  ,
XCHNG_TYPE_ID	INT                    NOT NULL  ,
ORDER_TYPE_ID	INT                    NOT NULL  ,
WM_STORE_ORG_ID	INT                    NOT NULL  ,
ORDER_REL_TS_KEY	  INT                   ,
ORDER_REL_DT_KEY	  INT                   ,
ORDER_PLACED_TS_KEY	    INT                 ,
ORDER_PLACED_DT_KEY	     INT                ,
CURR_STS_ID_KEY	INT                      ,
BILL_TO_ADDR_ID_KEY	INT                  ,
BILL_TO_CUST_ID_KEY	INT                  ,
CUST_CNTCT_ID_KEY	INT                );
DROP TABLE fact_sales_order_IN1542

INSERT INTO fact_sales_order_IN1542 
SELECT 
IIF(so.SALES_ORDER_NUM    IS NULL OR   so.SALES_ORDER_NUM='null',101,CONVERT(BIGINT,LTRIM(RTRIM(so.SALES_ORDER_NUM))))as SALES_ORDER_NUM
,IIF(so.TENANT_ORG_ID    IS NULL OR   so.TENANT_ORG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(so.TENANT_ORG_ID))))as TENANT_ORG_ID
,IIF(so.ORDER_REL_TS    IS NULL OR   so.ORDER_REL_TS='null','01-01-1900',CONVERT(DATETIME,LTRIM(RTRIM(so.ORDER_REL_TS))))as ORDER_REL_TS
,IIF(so.ORDER_REL_DT    IS NULL OR   so.ORDER_REL_DT='null','01-01-1900',CONVERT(DATE,LTRIM(RTRIM(so.ORDER_REL_DT))))as ORDER_REL_DT
,IIF(so.ORDER_PLACED_TS    IS NULL OR   so.ORDER_PLACED_TS='null','01-01-1900',CONVERT(DATETIME,LTRIM(RTRIM(so.ORDER_PLACED_TS))))as ORDER_PLACED_TS
,IIF(so.ORDER_PLACED_DT    IS NULL OR   so.ORDER_PLACED_DT='null','01-01-1900',CONVERT(DATE,LTRIM(RTRIM(so.ORDER_PLACED_DT))))as ORDER_PLACED_DT
,IIF(so.TOT_AMT    IS NULL OR   so.TOT_AMT='null',0 ,CONVERT(float,LTRIM(RTRIM(so.TOT_AMT))))as TOT_AMT
,IIF(so.TAX_AMT    IS NULL OR   so.TAX_AMT='null', 0,CONVERT(float,LTRIM(RTRIM(so.TAX_AMT))))as TAX_AMT
,IIF(so.CURR_STS_ID    IS NULL OR   so.CURR_STS_ID='null',101,CONVERT(INT,LTRIM(RTRIM(so.CURR_STS_ID))))as CURR_STS_ID
,IIF(so.BILL_TO_ADDR_ID    IS NULL OR   so.BILL_TO_ADDR_ID='null','N/A',LTRIM(RTRIM(so.BILL_TO_ADDR_ID)))as BILL_TO_ADDR_ID
,IIF(so.BILL_TO_CUST_ID    IS NULL OR  so.BILL_TO_CUST_ID='null','N/A',LTRIM(RTRIM(so.BILL_TO_CUST_ID)))as BILL_TO_CUST_ID
,IIF(so.CUST_CNTCT_ID    IS NULL OR   so.CUST_CNTCT_ID='null','N/A',LTRIM(RTRIM(so.CUST_CNTCT_ID)))as CUST_CNTCT_ID
,IIF(so.GUEST_ORDER_IND    IS NULL OR  so.GUEST_ORDER_IND='null',101,CONVERT(int,LTRIM(RTRIM(so.GUEST_ORDER_IND))))as GUEST_ORDER_IND
,IIF(so.CORP_ORDER_IND    IS NULL OR  so.CORP_ORDER_IND='null',101,CONVERT(int,LTRIM(RTRIM(so.CORP_ORDER_IND))))as CORP_ORDER_IND
,IIF(so.DEVICE_TYPE    IS NULL OR   so.DEVICE_TYPE='null','N/A',LTRIM(RTRIM(so.DEVICE_TYPE)))as DEVICE_TYPE
,IIF(so.IP_ADDR    IS NULL OR   so.IP_ADDR='null','N/A',LTRIM(RTRIM(so.IP_ADDR)))as IP_ADDR
,IIF(so.FRAUD_CHECK_REQD_IND    IS NULL OR   so.FRAUD_CHECK_REQD_IND='null',101,CONVERT(int,LTRIM(RTRIM(so.FRAUD_CHECK_REQD_IND))))as FRAUD_CHECK_REQD_IND
,IIF(so.ORIG_SALES_ORDER_NUM    IS NULL OR   so.ORIG_SALES_ORDER_NUM='null','N/A',LTRIM(RTRIM(so.ORIG_SALES_ORDER_NUM)))as ORIG_SALES_ORDER_NUM
,IIF(so.HOLD_FLAG    IS NULL OR   so.HOLD_FLAG='null',101,CONVERT(int,LTRIM(RTRIM(so.HOLD_FLAG))))as HOLD_FLAG
,IIF(so.XCHNG_TYPE_ID    IS NULL OR   so.XCHNG_TYPE_ID='null',101,CONVERT(INT,LTRIM(RTRIM(so.XCHNG_TYPE_ID))))as XCHNG_TYPE_ID
,IIF(so.ORDER_TYPE_ID    IS NULL OR   so.ORDER_TYPE_ID='null',101,CONVERT(INT,LTRIM(RTRIM(so.ORDER_TYPE_ID))))as ORDER_TYPE_ID
,IIF(so.WM_STORE_ORG_ID    IS NULL OR   so.WM_STORE_ORG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(so.WM_STORE_ORG_ID))))as WM_STORE_ORG_ID
,isnull(DH.daY_HOUR_KEY,-1) AS ORDER_REL_TS_KEY	       
,isnull(D.DAY_KEY,-1)   as ORDER_REL_DT_KEY
,ISNULL(DH1.daY_HOUR_KEY,-1) as ORDER_PLACED_TS_KEY
,isnull(D1.DAY_KEY,1) as ORDER_PLACED_DT_KEY 
 ,IIF(ST.STS_LKP_KEY IS NULL,-1,ST.STS_LKP_KEY )as CURR_STS_ID_KEY
 ,IIF(ADDR.CUST_ADDR_KEY IS NULL,-1,ADDR.CUST_ADDR_KEY) as BILL_TO_ADDR_ID_KEY
 ,IIF(addr1.CUST_AADR1_KEY IS NULL,-1,addr1.CUST_AADR1_KEY )as BILL_TO_CUST_ID_KEY
 ,IIF(c.CUST_CNTCT_KEY IS NULL ,-1,c.CUST_CNTCT_KEY)as CUST_CNTCT_ID_KEY
 FROM [BCMPWMT].[SALES_ORDER] so 
left join   DIM_STS_LKP_sql_IN1542  st  
 on st.sts_id   = IIF(so.CURR_STS_ID    IS NULL OR   so.CURR_STS_ID='null',101,LTRIM(RTRIM(so.CURR_STS_ID)))
 left join dim_cust_address_SQL_IN1542 addr 
 on  addr.addr_id   =IIF(so.BILL_TO_ADDR_ID    IS NULL OR   so.BILL_TO_ADDR_ID='null',101.00,CONVERT(FLOAT,LTRIM(RTRIM(so.BILL_TO_ADDR_ID))))
 left join dim_cust_addr1_sql_IN1542 addr1 
 on addr1.addr_id= IIF(so.BILL_TO_ADDR_ID    IS NULL OR   so.BILL_TO_ADDR_ID='null',101,CONVERT(BIGINT,LTRIM(RTRIM(so.BILL_TO_ADDR_ID))))
 left join DIM_CUST_CNTCT_SQL_IN1542 c 
 on c.CNTCT_ID  =IIF(so.CUST_CNTCT_ID    IS NULL OR   so.CUST_CNTCT_ID='null',101,CONVERT(INT,LTRIM(RTRIM(so.CUST_CNTCT_ID))))

LEFT JOIN DIM_DAY_HOUR_sql_IN1542 DH ON DH.DATE_ID=iif(so.ORDER_REL_TS  IS NULL OR so.ORDER_REL_TS  ='NULL','01-01-1900',CONVERT(DATE,so.ORDER_REL_TS))
and DH.hour_id=iif(so.ORDER_REL_TS is null or so.ORDER_REL_TS='null',-1,DATEPART(HOUR,convert(datetime,so.ORDER_REL_TS)))
LEFT JOIN dim_day_SQL_IN1542 D ON iif(so.ORDER_REL_DT is null or so.ORDER_REL_DT='null','01-01-1900',convert(date,so.ORDER_REL_DT))=D.date_id 
left join
DIM_DAY_HOUR_sql_IN1542 DH1 ON
iif(so.ORDER_PLACED_TS is null or so.ORDER_PLACED_TS='null','01-01-1900',convert(datetime,so.ORDER_PLACED_TS))=DH1.date_id
AND iif(so.ORDER_PLACED_TS is null or so.ORDER_PLACED_TS='null',-1, DATEPART(HOUR,so.ORDER_PLACED_TS))=DH1.HOUR_ID
LEFT JOIN dim_day_SQL_IN1542 D1 ON iif(so.ORDER_PLACED_DT is null or so.ORDER_PLACED_DT='null','01-01-1900',convert(date,so.ORDER_PLACED_DT))= d1.DATE_ID
-----------------------------------------------------------------
CREATE TABLE FACT_sales_order_adj_IN1542
(
ADJ_ID	 varchar(50)    PRIMARY KEY         ,
SALES_ORDER_NUM	BIGINT          ,
SALES_ORDER_LINE_NUM	INT     ,
TENANT_ORG_ID	INT             ,
CHARGE_CATEG_ID	INT             ,
CHRG_CATEG_MAP_ID	INT         ,
CHRG_NM	varchar(50)             ,
RSN_CD	INT                     ,
QTY	int                         ,
ADJUSMENT_AMT	float           ,
ADJ_RPT_TS	DATETIME            ,
RTN_IND	int                     ,
RTN_TS	DATETIME                ,
XCHNG_IND	int                 ,
ADJ_RPT_TS_KEY	int             ,
RTN_TS_KEY	int                 ,
RFND_TS_KEY	int                 ,
RFND_TS	DATETIME           )     

charge_categ_key	INT         ,
Rsn_cd_KEY	int                )
DROP TABLE FACT_sales_order_adj_IN1542
---------------------------------------
INSERT INTO FACT_sales_order_adj_IN1542

SELECT
IIF( oa.ADJ_ID    IS NULL OR            oa.ADJ_ID='null','N/A',LTRIM(RTRIM(ADJ_ID)))as ADJ_ID
,IIF(oa.SALES_ORDER_NUM    IS NULL OR   oa.SALES_ORDER_NUM='null',101,CONVERT(BIGINT,LTRIM(RTRIM(oa.SALES_ORDER_NUM))))as SALES_ORDER_NUM
,IIF(oa.SALES_ORDER_LINE_NUM    IS NULL OR  oa. SALES_ORDER_LINE_NUM='null',101,CONVERT(INT,LTRIM(RTRIM(oa.SALES_ORDER_LINE_NUM))))as SALES_ORDER_LINE_NUM
,IIF(oa.TENANT_ORG_ID    IS NULL OR      oa.TENANT_ORG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(oa.TENANT_ORG_ID))))as TENANT_ORG_ID
,IIF(oa.CHARGE_CATEG_ID    IS NULL OR     oa.CHARGE_CATEG_ID='null',101,CONVERT(INT,LTRIM(RTRIM(oa.CHARGE_CATEG_ID))))as CHARGE_CATEG_ID
,IIF(oa.CHRG_CATEG_MAP_ID    IS NULL OR   oa.CHRG_CATEG_MAP_ID='null',101,CONVERT(INT,LTRIM(RTRIM(oa.CHRG_CATEG_MAP_ID))))as CHRG_CATEG_MAP_ID
,IIF(oa.CHRG_NM    IS NULL OR   oa.CHRG_NM='null','N/A',LTRIM(RTRIM(oa.CHRG_NM)))as CHRG_NM
,IIF(oa.RSN_CD LIKE '%[A-Z]%' OR oa.RSN_CD    IS NULL OR   RSN_CD='null',101,CONVERT(INT,LTRIM(RTRIM(oa.RSN_CD))))as RSN_CD
,IIF(oa.QTY    IS NULL OR   oa.QTY='null',0,CONVERT(float,LTRIM(RTRIM(oa.QTY))))as QTY
,IIF(oa.ADJUSMENT_AMT    IS NULL OR   oa.ADJUSMENT_AMT='null',0 ,CONVERT(float,LTRIM(RTRIM(oa.ADJUSMENT_AMT))))as ADJUSMENT_AMT
,IIF(oa.ADJ_RPT_TS    IS NULL OR   oa.ADJ_RPT_TS='null','01-01-1900',CONVERT(DATETIME,LTRIM(RTRIM(oa.ADJ_RPT_TS))))as ADJ_RPT_TS
,IIF(oa.RTN_IND    IS NULL OR   oa.RTN_IND='null',101,CONVERT(int,LTRIM(RTRIM(oa.RTN_IND))))as RTN_IND
,IIF(oa.RTN_TS    IS NULL OR   oa.RTN_TS='null','01-01-1900',CONVERT(DATETIME,LTRIM(RTRIM(oa.RTN_TS))))as RTN_TS
,IIF(oa.XCHNG_IND    IS NULL OR   oa.XCHNG_IND='null',101,CONVERT(int,LTRIM(RTRIM(oa.XCHNG_IND))))as XCHNG_IND
,isnull(DH.day_key,-1) as ADJ_RPT_TS_KEY          
,isnull(DH1.day_key,-1)as RTN_TS_KEY	                
,isnull(DH2.day_key,-1)as RFND_TS_KEY	               
,IIF(oa.RFND_TS IS NULL OR   oa.RFND_TS='null','01-01-1900',CONVERT(DATETIME,LTRIM(RTRIM(oa.RFND_TS)))) AS RFND_TS
from [BCMPWMT].[SALES_ORDER_ADJ] oa 
LEFT JOIN DIM_DAY_HOUR_sql_IN1542 DH
on  DH.DATE_ID=iif(oa.ADJ_RPT_TS  IS NULL OR oa.ADJ_RPT_TS  ='NULL','01-01-1900',CONVERT(DATE,oa.ADJ_RPT_TS))
and DH.hour_id=iif(oa.ADJ_RPT_TS is null or oa.ADJ_RPT_TS ='null',-1,DATEPART(HOUR,convert(datetime,oa.ADJ_RPT_TS)))
left join DIM_DAY_HOUR_sql_IN1542 DH1
on  DH1.DATE_ID=iif(oa.RTN_TS  IS NULL OR oa.RTN_TS  ='NULL','01-01-1900',CONVERT(DATE,oa.RTN_TS))
and DH1.hour_id=iif(oa.RTN_TS is null or oa.RTN_TS ='null',-1,DATEPART(HOUR,convert(datetime,oa.RTN_TS)))
left join DIM_DAY_HOUR_sql_IN1542 DH2
on  DH2.DATE_ID=iif(oa.RFND_TS  IS NULL OR oa.RFND_TS  ='NULL','01-01-1900',CONVERT(DATE,oa.RFND_TS))
and DH2.hour_id=iif(oa.RFND_TS is null or oa.RFND_TS ='null',-1,DATEPART(HOUR,convert(datetime,oa.RFND_TS)))


alter TABLE FACT_sales_order_adj_IN1542 add charge_categ_key INT

alter TABLE FACT_sales_order_adj_IN1542 add Rsn_cd_KEY INT
RTN_TS_KEY	
ADJ_RPT_TS_KEY  
charge_categ_key
Rsn_cd_KEY 
RFND_TS_KEY
select * from DIM_CHARGE_CATEG_SQL_IN1542
select * from dim_RSN_LKP_sql_IN1542
select * from FACT_sales_order_adj_IN1542

UPDATE FACT_sales_order_adj_IN1542 SET charge_categ_key=D.[CHARGE_CATEG_KEY]
FROM  FACT_sales_order_adj_IN1542 F LEFT JOIN DIM_CHARGE_CATEG_SQL_IN1542 D ON
D.[CHARGE_CATEG_ID]=F.CHARGE_CATEG_ID


UPDATE FACT_sales_order_adj_IN1542 SET RSN_CD_KEY=D.RSN_KEY
FROM FACT_sales_order_adj_IN1542 F LEFT JOIN dim_RSN_LKP_sql_IN1542 D ON
D.RSN_CD=F.RSN_CD
-------------------------------------------------------