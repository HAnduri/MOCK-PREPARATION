CREATE TABLE DIM_TITLE_SQL_IN1542(
Title_Key	Int	IDENTITY(1,1) PRIMARY KEY,		
Title_ID	varchar	(15)					 ,
Title_Desc	varchar	(100)					 ,
Type	char	(20)						 ,
Pub_ID	char	(10)						 ,
Price	decimal		(19,	4	)			 ,
Notes	varchar	(300)						 ,
Publish_Date	varchar	(20)				 ,
Author_Name	varchar	(100)	     	     	 ,

Author_Phone	char	(20)	     	     ,
Author_Address	varchar	(40)	     	     ,
Author_City	varchar	(20)	     	     	 ,
Author_State	char	(2)	     	     ,
Author_Zip	char	(7)	     	     	 ,
AU_Contract_Status	varchar(15)	     	     )
drop table DIM_TITLE_SQL_IN1542

SELECT * FROM[BCMPPBS].[authors] A

SELECT * FROM [BCMPPBS].[titleauthor]TA
SELECT * FROM [BCMPPBS].[titles]T


SELECT * FROM[BCMPPBS].[authors] A

insert into DIM_TITLE_SQL_IN1542
SELECT 
IIF(T.TITLE_ID IS NULL,'NA' ,CONCAT('T-',convert(varchar(50),T.TITLE_ID),'-001')) Title_ID,
iif(t.type is null and T.Title is null ,'Type Not Found',CONCAT(UPPER(T. Type),'-',Upper(T.Title  )))Title_Desc,
iif(T.type is null ,'Type Not Found',CONCAT('TT-',STUFF(LOWER(T.Type),1,1,UPPER(SUBSTRING(T.TYPE,1,1))))) TYPE,
iif(t.Pub_ID is null ,'No Publisher ID Found',UPPER(LTRIM(RTRIM(t.Pub_ID)))) Pub_ID,
iif(T.price is null ,0,CASE WHEN T.price < 2 THEN T.price*(130/100) 
else  T.price*(110/100) 
END) AS PRICE ,
iif(T.NOTES is null ,'Notes Not Found',CONCAT (SUBSTRING(T.NOTES,1,3),SUBSTRING(T.NOTES,LEN(T.NOTES)-2,2))) NOTES,
iif (t.pubdate is null,'1900-JAN-01', FORMAT(t.PUBDATE,'yyyy-MMM-dd') ) Publish_Date,
concat(substring(a.[au_lname],1,1),'-',substring(   a.[au_fname],1,1)) Author_Name,
iif(a.phone is null,'+91-(999)-(999)-9999',format( convert(bigint,replace(replace((a.phone),' ',''),'-','')),'+91-(###)-(###)-####')) Author_Phone,
 IIF(a.address is null,'ABC 12345',replace(translate(replace(ltrim(rtrim(a.address)),' ',','),'0123456789','          '),' ','' ))   Author_Address,
 iif (a.city  is null,'NA',a.city)   Author_City,

 IIF(A.STATE IS NULL,'NA',UPPER(LTRIM(RTRIM(A.STATE)))) Author_State,
 IIF(A.ZIP IS NULL,'NA',concat(substring(left(cast(A.ZIP as varchar(15))+replicate('0',6),6),1,3),' ',substring(left(cast(A.ZIP as varchar(15))+replicate('0',6),6),4,3))) Author_Zip,
case when a.contract= 1 then 'Active'
else 'De-Active' end  as  AU_Contract_Status
 
FROM
[BCMPPBS].[titles]T LEFT JOIN [BCMPPBS].[titleauthor]TA
ON T.TITLE_ID=TA.TITLE_ID
LEFT JOIN [BCMPPBS].[authors] A 
ON A.AU_ID=TA.AU_ID

select * from DIM_TITLE_SQL_IN1542