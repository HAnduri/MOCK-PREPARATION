

select * from DIM_CHARGE_CATEG_infa_IN1542
select * from [BCMPWMT].[CHARGE_CATEG_LKP]
-----------------------
select * from DIM_CUST_infa_IN1542
select * from [BCMPWMT].[CUST]
-------------------
select * from dim_CUST_ACCT_infa_IN1542
select * from [BCMPWMT].[CUST_ACCT]
-----------------
select * from dim_cust_address_infa_IN1542
select * from [BCMPWMT].[CUST_ADDR]
--------------
select * from dim_cust_addr_zone_infa_IN1542
select * from [BCMPWMT].[CUST_ADDR_ZONE]
-----------
select * from dim_cust_addr1_infa_IN1542
select * from [BCMPWMT].[CUST_ADDR1]
----------------
select * from DIM_CUST_CNTCT_infa_IN1542
select * from [BCMPWMT].[CUST_CNTCT]
---------------------
select * from DIM_CUST_EMAIL_infa_IN1542
select * from [BCMPWMT].[CUST_EMAIL]

TRUNCATE TABLE DIM_CUST_EMAIL_infa_IN1542
TRUNCATE TABLE 
TRUNCATE TABLE Dim_FULFMT_TYPE_LKP_infa_IN1542

------------------------------------------------
select * from DIM_CUST_PHONE_infa_IN1542
select * from [BCMPWMT].[CUST_PHONE]
------------------------------------
select * from Dim_FULFMT_TYPE_LKP_infa_IN1542
select * from [BCMPWMT].[FULFMT_TYPE_LKP]

select * from Dim_OFFR_infa_IN1542
select * from [BCMPWMT].[OFFR]
select * from Dim_ORDER_STS_MASTER_LKP_infa_IN1542
select * from [BCMPWMT].[ORDER_STS_MASTER_LKP]
select * from DIM_ORG_BUSINESS_UNIT_infa_IN1542
select * from [BCMPWMT].[ORG_BUSINESS_UNIT]
SELECT * INTO Dim_ORG_TYPE_LKP_infa_IN1542

FROM Dim_ORG_TYPE_LKP_SQL_IN1542
select * from Dim_ORG_TYPE_LKP_infa_IN1542
select * from [BCMPWMT].[ORG_TYPE_LKP]
select * from dim_prod_infa_IN1542
select * from 
TRUNCATE TABLE dim_prod_rpt_hrchy_infa_IN1542
select * from dim_prod_rpt_hrchy_infa_IN1542
select * from
select * from dim_rpt_hrchy_infa_IN1542
select * from
select * from dim_RSN_LKP_infa_IN1542
select * from
select * from Dim_RSN_TYPE_LKP_infa_in1542
select * from
select * from DIM_STS_LKP_infa_IN1542
select * from
select * from DIM_CUST_ACCT_DETAILS_infa_IN1542

create table Fact_sales_order_adj_INFA_IN1542
(ADJ_ID    varchar(50)            NOT NULL,
SALES_ORDER_NUM    BIGINT        NOT NULL,
SALES_ORDER_LINE_NUM    INT    NOT NULL,
TENANT_ORG_ID    INT            NOT NULL,
CHARGE_CATEG_ID    INT            NOT NULL,
CHRG_CATEG_MAP_ID    INT        NOT NULL,
CHRG_NM    varchar(50)            NOT NULL,
RSN_CD    INT                    NOT NULL,
QTY    int                        NOT NULL,
ADJUSMENT_AMT    float        NOT NULL,
ADJ_RPT_TS    DATETIME        NOT NULL,
RTN_IND    int                    NOT NULL,
RTN_TS    DATETIME            NOT NULL,
XCHNG_IND    int                NOT NULL,
ADJ_RPT_TS_KEY    int            NOT NULL,
RTN_TS_KEY    int                NOT NULL,
RFND_TS_KEY    int                NOT NULL,
RFND_TS    DATETIME NOT NULL)


alter TABLE Fact_sales_order_adj_INFA_IN1542 add charge_categ_key INT,
Rsn_cd_KEY INT

SELECT * FROM BCMPWMT.SALES_ORDER_ADJ

SELECT * FROM [BCMPWMT].[SALES_ORDER_ADJ]
SELECT * FROM  Fact_sales_order_adj_INFA_IN1542


INSERT INTO Fact_sales_order_adj_INFA_IN1542
SELECT * FROM Fact_sales_order_adj_SQL_IN1542

TRUNCATE TABLE Fact_sales_order_adj_INFA_IN1542