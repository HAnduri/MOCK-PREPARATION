
select * from [BCMPWMT].[SALES_ORDER]

create table Dates_sql_IN1542
(id int primary key not null,
Dates date,
year_id int
)

create procedure DATESA_SQL_IN1542
as
declare @start_date date = '01-01-1992'
declare @end_date date = '12-31-2024'
declare @count int =0
declare @year int =1992
declare @year_id int = 1 
while @start_date <= @end_date
	begin
		insert into Dates values(@count+1,@start_date,@year_id)
		set @count = @count+1
		set @start_date = dateadd(day,1,@start_date)
		if @year <> year(@start_date)
			set @year_id = @year_id+1
			set @year = year(@start_date)
	end
exec DATESA_SQL_IN1542

SELECT * FROM DATESA_SQL_IN1542


	create table DIM_YEAR_SQL_IN1542
(
year_key int not null identity(1,1) primary key,
year_id int not null 
)

drop table DIM_YEAR_SQL_IN1542

insert into DIM_YEAR_SQL_IN1542
select distinct(year(Dates)) from Dates
order by year(Dates)

select * from DIM_YEAR_SQL_IN1542

create table DIM_QTR_SQL_IN1542
(quater_key int identity(1,1) primary key,
quater_id int not null,
year_key int not null,
year_id int not null
foreign key (year_key) references DIM_YEAR_SQL_IN1542(year_key))


truncate table DIM_QTR_SQL_IN1542

insert into DIM_QTR_SQL_IN1542(quater_id,year_key,year_id)
select distinct(datename(qq,d.dates)) as quater_id,y.year_key,y.year_id
from DIM_YEAR_SQL_IN1542 y join dates d on y.year_key = d.year_id
order by y.year_id

create table DIM_MONTH_IN1542_IN1542
(month_key int not null primary key identity(1,1),
month_id int ,
month_name varchar(20),
quater_key int not null,
quater_id int not null,
year_key int not null,
year_id int not null
foreign key (year_key) references DIM_YEAR_SQL_IN1542(year_key),
foreign key (quater_key) references DIM_QTR_SQL_IN1542(quater_key)
);
drop table DIM_MONTH_IN1542
insert into  DIM_MONTH_IN1542(month_id,month_name,quater_key,quater_id,year_key,year_id)

select distinct(month(d.dates)),
datename(month,d.dates),
q.quater_key,
q.quater_id,
q.year_key,
q.year_id
from dates d join DIM_QTR_SQL_IN1542 q on year(d.dates) = q.year_id and datepart(qq,d.dates) = q.quater_id
order by year_id



select * from dates
select * from DIM_YEAR_SQL_IN1542
select * from DIM_QTR_SQL_IN1542
select * from DIM_MONTH_IN1542
select* from DIM_WEEK_SQL_IN1542
select * from DIM_WEEK_SQL_IN1542

create table DIM_WEEK_SQL_IN1542
(week_key int identity(1,1) primary key,
week_id int not null,
Month_key int not null,
month_id int not null,
quater_key int not null,
quater_id int not null,
year_key int not null,
year_id int not null);

insert into DIM_WEEK_SQL_IN1542(week_id,Month_key,month_id,quater_key,quater_id,year_key
,year_id)
select distinct(datepart(ww,d.dates)),
m.Month_key,
m.month_id,
m.quater_key,
m.quater_id,
m.year_key,
m.year_id
from dates d join DIM_MONTH_IN1542 m on year(d.dates) = m.year_id
and datepart(qq,d.dates) = m.quater_id
and datepart(mm,d.dates) = m.month_id
order by year_id

select * from DIM_WEEK_SQL_IN1542
drop table DIM_WEEK_SQL_IN1542
create table DIM_WEEK_SQL_IN1542
(Day_key int identity(1,1) primary key,
Date_id date  not null,
Day_id		int not null,
week_key	int not null,
Week_id		int not null,
Month_key	int not null,
Month_id	int not null,
Quarter_key	int not null,
Quarter_id	int not null,
year_key	int not null,
year_id		int not null);


insert into DIM_WEEK_SQL_IN1542
(
Date_id		,
Day_id		,
week_key	,
Week_id		,
Month_key	,
Month_id	,
Quarter_key	,
Quarter_id	,
year_key	,
year_id		)

select distinct(d.dates),datepart(dd,d.dates),
w.week_key		,
w.Week_id		,
w.Month_key		,
w.Month_id		,
w.quater_key	,
w.quater_id	,
w.year_key		,
w.year_id
from dates d join DIM_WEEK_SQL_IN1542_SQL_IN1542 w on year(d.dates) = w.year_id
and datepart(qq,d.dates) = w.quater_id
and datepart(mm,d.dates) = w.month_id
and datepart(ww,d.dates) = w.week_id
order by year_id




drop table DIM_WEEK_SQL_IN1542
truncate table DIM_WEEK_SQL_IN1542
select * from DIM_WEEK_SQL_IN1542
order by date_id






select * from [BCMPWMT].[SALES_ORDER]
