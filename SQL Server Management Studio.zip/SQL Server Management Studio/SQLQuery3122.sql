
create table DIM_CUST_CNTCT_SQL_IN1542(
CUST_CNTCT_KEY  int identity(1,1) primary key	NOT NULL			,
CNTCT_ID  int  NOT NULL						,
TENANT_ORG_ID  int  NOT NULL				,
SRC_CNTCT_ID  varchar(50)  NOT NULL			,	
DATA_SRC_ID  int  NOT NULL					,
ACCT_ID  int  NOT NULL						,
ADDR_ID  bigint  NOT NULL						,
PHONE_ID  bigint  NOT NULL						,
EMAIL_ID  varchar(250)  NOT NULL			,	
ADDR_ZONE_ID  int  NOT NULL					,
DELTD_YN  char(1)  NOT NULL					,
CRE_DT  Date  NOT NULL						,
UPD_TS  nvarchar(255)  NOT NULL				
		
)
drop table DIM_CUST_CNTCT_SQL_IN1542
INSERT INTO DIM_CUST_CNTCT_SQL_IN1542 
SELECT 


IIF(CNTCT_ID    IS NULL OR   CNTCT_ID='null',101,cast(ltrim(rtrim(Cntct_id)) as int))as CNTCT_ID
,IIF(TENANT_ORG_ID    IS NULL OR   TENANT_ORG_ID='null',101,cast(ltrim(rtrim(Tenant_org_id)) as int))as TENANT_ORG_ID
,IIF(SRC_CNTCT_ID    IS NULL OR   SRC_CNTCT_ID='null','N/A',ltrim(rtrim(SRC_CNTCT_ID)))as SRC_CNTCT_ID
,IIF(DATA_SRC_ID    IS NULL OR   DATA_SRC_ID='null',101,cast(ltrim(rtrim(Data_src_id)) as int))as DATA_SRC_ID
,IIF(ACCT_ID    IS NULL OR   ACCT_ID='null',101,cast(ltrim(rtrim(Acct_id)) as int))as ACCT_ID
,IIF(ADDR_ID    IS NULL OR   ADDR_ID='null',101,cast(ltrim(rtrim(Addr_id)) as bigint))as ADDR_ID
,IIF(PHONE_ID    IS NULL OR   PHONE_ID='null',101,cast(ltrim(rtrim(Phone_id)) as bigint))as PHONE_ID
,IIF(EMAIL_ID    IS NULL OR   EMAIL_ID='null','N/A',ltrim(rtrim(Email_ID)))as EMAIL_ID
,IIF(ADDR_ZONE_ID    IS NULL OR   ADDR_ZONE_ID='null',101,cast(ltrim(rtrim(Addr_Zone_Id))as int))as ADDR_ZONE_ID
,IIF(DELTD_YN    IS NULL OR   DELTD_YN='null','N/A' ,cast(ltrim(rtrim(Deltd_yn)) as char)) as DELTD_YN
,IIF(CRE_DT    IS NULL OR   CRE_DT='null','01-01-1900',cast(ltrim(rtrim(Cre_Dt))as Date ))as CRE_DT
,IIF(UPD_TS    IS NULL OR   UPD_TS='null',format(cast('01-01-1990' as datetime),'dd/MMMM/yyyy'), format(cast(UPD_TS as datetime),'dd/MMMM/yyyy'))as UPD_TS



FROM [BCMPWMT].[CUST_CNTCT]

SELECT * FROM DIM_CUST_CNTCT_SQL_IN1542

SELECT addr_zone_id_key  FROM DIM_CUST_CNTCT_SQL_IN1542


CUST_PHONE_KEY,
Cust_email_key,
cust_acct_key,
addr_zone_id_key 
FROM DIM_CUST_CNTCT_SQL_IN1542


SELECT [ addr_zone_id_key  ] FROM [IN1542].[DIM_CUST_CNTCT_SQL_IN1542]