select
count(aa.productkey),
count(aa.orderdatekey),
count(aa.duedatekey),
count(aa.shipdatekey),
count(aa.promotionkey),
count(aa.currencykey),
count(aa.salesterritorykey),
count(aa.customerkey)
from
factresellersales fis
left outer join
(select
store.productkey,
dt1.timekey OrderDateKey,
dt2.timekey DueDateKey,
dt3.timekey ShipDateKey,
dp.PromotionKey,
cc.CurrencyKey,
dst.SalesTerritoryKey,
dc.customerkey,
soh.SalesOrderNumber,
sod.salesorderdetailid SalesOrderLineNumber,
soh.RevisionNumber,
sod.OrderQty OrderQuantity,
sod.UnitPrice,
sod.UnitPriceDiscount DiscountAmount,
store.StandardCost,
soh.SubTotal,
soh.TaxAmt TaxAmt,
soh.Freight Freight,
sod.CarrierTrackingNumber CarrierTrackingNumber,
soh.PurchaseOrderNumber PONumber
from
SalesOrderHeader soh
join
SalesOrderDetail sod
on
soh.SalesOrderID = sod.SalesOrderID
and
soh.OnlineOrderFlag=0
left outer join
(select distinct ProductKey,productid prod_id,pdt.standardcost
 from
 dim_product dpdt
 left outer join
 Product  pdt
 on
 dpdt.ProductAlternateKey = pdt.ProductNumber
 and 
 dpdt.status='current')store
on
sod.productID=store.prod_id
left outer join
dimtime dt1
on
soh.orderdate=dt1.FullDateAlternateKey
left outer join
dimtime dt2
on
soh.duedate=dt2.FullDateAlternateKey
left outer join
dimtime dt3
on
soh.shipdate=dt3.FullDateAlternateKey
left outer join
dim_promotion dp
on
sod.SpecialOfferID=dp.PromotionAlternateKey
left outer join
(select distinct cr.tocurrencycode, cr.currencyrateid,dc.currencykey,cr.currencyratedate
 from
 dim_currency dc
 join
 CurrencyRate cr
 on
 dc.CurrencyAlternateKey=cr.tocurrencycode)cc
on
 soh.currencyrateid=cc.currencyrateid
 and
 soh.orderdate=cc.currencyratedate 
left outer join
dim_salesterritory dst
on
Soh.TerritoryID=dst.SalesTerritoryAlternateKey 
left outer join
dim_customer dc
on
soh.CustomerID = dc.customerkey)aa
on
fis.salesordernumber = aa.salesordernumber
where
fis.prod_key = aa.productkey
and
fis.orderdatekey = aa.orderdatekey
and
fis.duedatekey = aa.duedatekey
and
fis.shipdatekey = aa.shipdatekey
and
fis.promotionkey = aa.promotionkey
and
fis.currencykey = aa.currencykey
and
fis.salesterritorykey = aa.salesterritorykey