
select count(*) from BCMPWMT.CUST_EMAIL
select count(*) from DIM_CUST_EMAIL_infa_IN1542	

---------------------------------

select deltd_yn,count(*) from DIM_CUST_EMAIL_infa_IN1542 GROUP BY  deltd_yn

select deltd_yn,count(*) from BCMPWMT.CUST_EMAIL GROUP BY  deltd_yn
------------------------------------------------------

select * from BCMPWMT.CUST_EMAIL	
WHERE EMAIL_ID=343970302

select * from DIM_CUST_EMAIL_infa_IN1542	
WHERE EMAIL_ID=343970302
----------------------------------------------------
-------------DISTINCT--------
SELECT COUNT(*) FROM DIM_CUST_EMAIL_infa_IN1542	 GROUP BY EMAIL_ID HAVING COUNT(*)>1
-------------------

select * from DIM_CHARGE_CATEG_infa_IN1542
truncate table DIM_CHARGE_CATEG_infa_IN1542
update DIM_CHARGE_CATEG_infa_IN1542 
set  charge_categ='hk'
where CHARGE_CATEG_ID=14
-------------
select * from  DIM_CUST_infa_IN1542
select * from  [BCMPWMT].[CUST]
TRUNCATE TABLE  DIM_CUST_infa_IN1542 
update DIM_CUST_infa_IN1542 
set salute='haRITHAA'
where cust_id=225656348


SELECT COUNT(*) FROM DIM_CUST_infa_IN1542
SELECT COUNT(*) FROM DIM_CUST_infa_IN1542

SELECT * FROM [BCMPWMT].[CUST_ADDR]


SELECT * FROM dim_CUST_ACCT_infa_IN1542 

SELECT * FROM  [BCMPWMT].[CUST_ACCT]  

update dim_CUST_ACCT_infa_IN1542 
set email='haritha123'
where acct_id=87005017
select * from dim_cust_address_infa_IN1542
select * from [BCMPWMT].[CUST_ADDR]

update dim_cust_address_infa_IN1542 
set town='KADAPA'
where addr_id=2923989525 

select * from dim_cust_addr_zone_infa_IN1542
select * from [BCMPWMT].[CUST_ADDR_ZONE]


select * from [BCMPWMT].[FULFMT_TYPE_LKP]


select * from Dim_FULFMT_TYPE_LKP_infa_IN1542





select * from DIM_CUST_PHONE_infa_IN1542
select * from dim_cust_addr1_infa_IN1542
SELECT * FROM [BCMPWMT].[ORDER_STS_MASTER_LKP]
SELECT * FROM Dim_ORDER_STS_MASTER_LKP_infa_IN1542
----------------------------
SELECT * FROM Dim_ORG_TYPE_LKP_infa_IN1542
update Dim_ORG_TYPE_LKP_infa_IN1542 
set parent_org_type_nm='SYSTECH'
where ORG_TYPE_ID=500

DROP TABLE Dim_ORG_TYPE_LKP_infa_IN1542-------
---------------------------------------------------------