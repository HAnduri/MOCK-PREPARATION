create table place(
id int primary key,
name_a varchar(50),
email_id nvarchar(70),
location_a nvarchar(100)
)

drop table place_tgt
create table  place_tgt(
id int primary key,
name_b varchar(50),
email_id_b nvarchar(70),
location_b nvarchar(100),
start_date datetime ,
end_date datetime null,
place1 nvarchar,
place2 nvarchar,
place3 nvarchar
)

insert into place
values
(1,'haritha','haritha@123','ngocolony#w7/567#chennai'),
(2,'anduri','anduri@123','colony#h56/ty#chennai'),
(3,'reddy','reddy@123','gocolony#t0/896#chennai')




