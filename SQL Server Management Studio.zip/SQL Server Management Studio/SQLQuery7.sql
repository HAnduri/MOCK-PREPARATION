CREATE TABLE FACT_RTN_ORDER_LINE_infa_IN1542(
rtn_order_key	int primary key identity(1,1)	,
RTN_ORDER_NUM	varchar(50)	not null	  ,	
RTN_LINE_NUM	varchar(50)	not null		  ,
TENANT_ORG_ID	int			 not null         ,
SALES_ORDER_NUM	bigint		  not null    ,
SALES_ORDER_LINE_NUM	int		not null	  ,
RCV_STORE_ORG_CD	varchar	(50) not null	    ,
RTN_QTY	float	     not null     ,
VIRT_RTN_IND	int			   not null       ,
AFFIDAVIT_SIGNUP_TS	datetime	not null	,	
ITEM_EXPC_BACK_FLAG	int			 not null     ,
RTN_LINE_MODFD_TS	datetime	not null	,	
RTN_LINE_CRE_TS	datetime	not null		,
RFND_FLAG	int	not null		              ,
RTN_RSN_CD	varchar(50)	not null		      ,
LINE_TOT_AMT	float	not null   ,
OTHR_CHRG_AMT	float	not null	  ,
RTN_CENTER_ORG_CD	INT	not null		  ,
SRC_CRE_TS	datetime	not null	  ,
SRC_UPD_TS	datetime	not null		  ,
RTN_LINE_CRE_DT	datetime	not null		,
CATLG_ITEM_ID	int		not null          ,
UNIT_PRICE	float	not null       ,
RTN_RSN_BUCKET	varchar(50)		not null  ,
RDC_ORG_ID	float	not null		      ,
ORDER_STS_ID	INT	not null		      ,
STS_LKP_KEY	INT	not null		          ,
PROD_KEY	INT	not null		          ,
RSN_LKP_KEY	INT	not null	          ,
AFFIDAVIT_SIGNUP_TS_KEY	INT	not null		,
RTN_LINE_MODFD_TS_KEY	INT	not null		,
RTN_LINE_CRE_TS_KEY	INT	not null	  ,
RTN_LINE_CRE_DT_KEY	INT	not null		  ) 


insert into FACT_RTN_ORDER_LINE_SQL_IN1542

select 

IIF(SO.RTN_ORDER_NUM like '%[a-zA-Z]%' OR SO.RTN_ORDER_NUM    IS NULL OR   SO.RTN_ORDER_NUM='null','N/A',ltrim(rtrim(RTN_ORDER_NUM   )))as RTN_ORDER_NUM
,IIF(SO.RTN_LINE_NUM like '%[a-zA-Z]%' OR RTN_LINE_NUM    IS NULL OR   SO.RTN_LINE_NUM='null','N/A',ltrim(rtrim(SO.RTN_LINE_NUM         )))as RTN_LINE_NUM
,IIF(SO.TENANT_ORG_ID  like '%[a-zA-Z]%' OR SO.TENANT_ORG_ID    IS NULL OR   SO.TENANT_ORG_ID='null',101,cast(ltrim(rtrim(SO.TENANT_ORG_ID) ) as int))as TENANT_ORG_ID
,IIF(SO.SALES_ORDER_NUM  like '%[a-zA-Z]%' OR SO.SALES_ORDER_NUM  IS NULL OR   SO.SALES_ORDER_NUM='null',101,cast(ltrim(rtrim(SO.SALES_ORDER_NUM      ))as bigint))as SALES_ORDER_NUM
,IIF(SO.SALES_ORDER_LINE_NUM  like '%[a-zA-Z]%' OR SO.SALES_ORDER_LINE_NUM    IS NULL OR  SO. SALES_ORDER_LINE_NUM='null',101,cast(ltrim(rtrim(SO.SALES_ORDER_LINE_NUM ))as int))as SALES_ORDER_LINE_NUM
,IIF(SO.RCV_STORE_ORG_CD like '%[a-zA-Z]%' OR SO.RCV_STORE_ORG_CD    IS NULL OR   SO.RCV_STORE_ORG_CD='null','N/A' ,ltrim(rtrim(SO.RCV_STORE_ORG_CD     )))as RCV_STORE_ORG_CD
,IIF(SO.RTN_QTY like '%[a-zA-Z]%' OR SO.RTN_QTY    IS NULL OR  SO. RTN_QTY='null', 0,cast(ltrim(rtrim(SO.RTN_QTY              ))as float))as RTN_QTY
,IIF(SO.VIRT_RTN_IND  like '%[a-zA-Z]%' OR SO.VIRT_RTN_IND    IS NULL OR   SO.VIRT_RTN_IND='null',101,cast(ltrim(rtrim(SO.VIRT_RTN_IND         ))as int))as VIRT_RTN_IND
,IIF(SO.AFFIDAVIT_SIGNUP_TS  like '%[a-zA-Z?]%' OR SO.AFFIDAVIT_SIGNUP_TS    IS NULL OR   SO.AFFIDAVIT_SIGNUP_TS='null','01-01-1900',cast(ltrim(rtrim(SO.AFFIDAVIT_SIGNUP_TS  ))as date))as AFFIDAVIT_SIGNUP_TS
,IIF(SO.ITEM_EXPC_BACK_FLAG like '%[a-zA-Z?]%' OR  SO.ITEM_EXPC_BACK_FLAG    IS NULL OR   SO.ITEM_EXPC_BACK_FLAG='null',101,cast(ltrim(rtrim(SO.ITEM_EXPC_BACK_FLAG  ))as int))as ITEM_EXPC_BACK_FLAG
 ,IIF(SO.RTN_LINE_MODFD_TS like '%[a-zA-Z?]%' OR SO.RTN_LINE_MODFD_TS    IS NULL OR   SO.RTN_LINE_MODFD_TS='null','01-01-1900',cast(ltrim(rtrim(SO.RTN_LINE_MODFD_TS ))as date ))as RTN_LINE_MODFD_TS
,IIF(SO.RTN_LINE_CRE_TS like '%[a-zA-Z?]%' OR SO.RTN_LINE_CRE_TS    IS NULL OR   RTN_LINE_CRE_TS='null','01-01-1900',CONVERT(datetime,LTRIM(RTRIM(RTN_LINE_CRE_TS))))as RTN_LINE_CRE_TS
,IIF(SO.RFND_FLAG  like '%[a-zA-Z?]%' OR SO.RFND_FLAG    IS NULL OR   SO.RFND_FLAG ='null',101,CONVERT(int,LTRIM(RTRIM(SO.RFND_FLAG ))))as RFND_FLAG
,IIF(SO.RTN_RSN_CD like '%[a-zA-Z?]%' OR SO.RTN_RSN_CD    IS NULL OR   SO.RTN_RSN_CD='null','N/A' ,ltrim(rtrim(SO.RTN_RSN_CD           )))as RTN_RSN_CD
,IIF(SO.LINE_TOT_AMT  like '%[a-zA-Z?]%' OR SO.LINE_TOT_AMT    IS NULL OR   SO.LINE_TOT_AMT ='null',0 ,CONVERT(float,LTRIM(RTRIM(LINE_TOT_AMT     ))))as LINE_TOT_AMT
,IIF(SO.OTHR_CHRG_AMT like '%[a-zA-Z?]%' OR SO.OTHR_CHRG_AMT    IS NULL OR   SO.OTHR_CHRG_AMT ='null',0 ,CONVERT(float,LTRIM(RTRIM(SO.OTHR_CHRG_AMT ))))as OTHR_CHRG_AMT
,IIF(SO.RTN_CENTER_ORG_CD like '%[a-zA-Z?]%' OR SO.RTN_CENTER_ORG_CD    IS NULL OR   SO.RTN_CENTER_ORG_CD ='null',101,CONVERT(int,LTRIM(RTRIM(SO.RTN_CENTER_ORG_CD     ))))as RTN_CENTER_ORG_CD
,IIF(SO.SRC_CRE_TS like '%[a-zA-Z?]%' OR SO.SRC_CRE_TS    IS NULL OR   SO.SRC_CRE_TS='null','01-01-1900',CONVERT(datetime,LTRIM(RTRIM(SO.SRC_CRE_TS))))as SRC_CRE_TS
,IIF(SO.SRC_UPD_TS like '%[a-zA-Z?]%' OR SO.SRC_UPD_TS    IS NULL OR   SO.SRC_UPD_TS='null','01-01-1900',CONVERT(datetime,LTRIM(RTRIM(SO.SRC_UPD_TS          ))))as SRC_UPD_TS
,IIF(SO.RTN_LINE_CRE_DT  like '%[a-zA-Z?]%' OR SO.RTN_LINE_CRE_DT    IS NULL OR  SO.RTN_LINE_CRE_DT  ='null','01-01-1900',CONVERT(datetime,LTRIM(RTRIM(SO.RTN_LINE_CRE_DT      )  )))as RTN_LINE_CRE_DT
,IIF(SO.CATLG_ITEM_ID like '%[a-zA-Z?]%' OR SO.CATLG_ITEM_ID    IS NULL OR   SO.CATLG_ITEM_ID='null',101,CONVERT(int,LTRIM(RTRIM(SO.CATLG_ITEM_ID      ) )))as CATLG_ITEM_ID
,IIF(SO.UNIT_PRICE like '%[a-zA-Z?]%' OR SO.UNIT_PRICE    IS NULL OR   SO.UNIT_PRICE ='null',0 ,CONVERT(float,LTRIM(RTRIM(SO.UNIT_PRICE        )   )))as UNIT_PRICE
,IIF(SO.RTN_RSN_BUCKET like '%[a-zA-Z?]%' OR SO.RTN_RSN_BUCKET    IS NULL OR   SO.RTN_RSN_BUCKET ='null','N/A',ltrim(rtrim(SO.RTN_RSN_BUCKET        )))as RTN_RSN_BUCKET
,IIF(SO.RDC_ORG_ID  like '%[a-zA-Z?]%' OR SO.RDC_ORG_ID    IS NULL OR   SO.RDC_ORG_ID  ='null',101 ,CONVERT(float,LTRIM(RTRIM(SO.RDC_ORG_ID             ))))as RDC_ORG_ID
,IIF(SO.ORDER_STS_ID  like '%[a-zA-Z?]%' OR SO.ORDER_STS_ID    IS NULL OR   ORDER_STS_ID='null',101,CONVERT(int,LTRIM(RTRIM(ORDER_STS_ID)      )   ))as ORDER_STS_ID
,S.STS_LKP_KEY as STS_LKP_KEY
,p.prod_key as PROD_KEY
,r.rsn_key as RSN_LKP_KEY  
,   DH.hour_key as  AFFIDAVIT_SIGNUP_TS_KEY
,DH1.hour_key as RTN_LINE_MODFD_TS_KEY
,DH2.hour_key as RTN_LINE_CRE_TS_KEY
 ,d.day_key      as        RTN_LINE_CRE_DT_KEY
  FROM 

 
 [BCMPWMT].[RTN_ORDER_LINE] SO LEFT JOIN IN1542.DIM_STS_LKP_sql_IN1542  S
 ON S.sts_id  =IIF(SO.ORDER_STS_ID LIKE '%[A-Za-z?]%' OR SO.ORDER_STS_ID     IS NULL OR    SO.ORDER_STS_ID ='null',101,CONVERT(INT,LTRIM(RTRIM(SO.ORDER_STS_ID )))) 
  left join IN1542.DIM_prod_SQL_IN1542 p
  ON p.catlg_item_id  =IIF(SO.catlg_item_id LIKE '%[A-Za-z?]%' OR SO.catlg_item_id     IS NULL OR   SO.catlg_item_id ='null',101,CONVERT(INT,LTRIM(RTRIM(SO.catlg_item_id )))) 
   left join IN1542.DIM_RSN_LKP_sql_IN1542 r
   ON r.rsn_id  =IIF(SO.rtn_rsn_cd LIKE '%[A-Za-z?]%' OR SO.rtn_rsn_cd    IS NULL OR    SO.rtn_rsn_cd='null',101,CONVERT(INT,LTRIM(RTRIM(SO.rtn_rsn_cd )))) 
 left join 
 DIM_DAY_HOUR_sql_IN1542 DH
on  DH.DATE_ID=iif(SO.AFFIDAVIT_SIGNUP_TS  IS NULL OR SO.AFFIDAVIT_SIGNUP_TS  ='NULL','01-01-1900',CONVERT(DATE,SO.AFFIDAVIT_SIGNUP_TS ))
and DH.hour_id=iif(SO.AFFIDAVIT_SIGNUP_TS  is null or SO.AFFIDAVIT_SIGNUP_TS ='null',-1,DATEPART(HOUR,convert(datetime,SO.AFFIDAVIT_SIGNUP_TS )))
left join 
 DIM_DAY_HOUR_sql_IN1542 DH1
on  DH1.DATE_ID=iif(SO.RTN_LINE_MODFD_TS IS NULL OR SO.RTN_LINE_MODFD_TS ='NULL','01-01-1900',CONVERT(DATE,SO.RTN_LINE_MODFD_TS ))
and DH1.hour_id=iif(SO.RTN_LINE_MODFD_TS  is null or SO.RTN_LINE_MODFD_TS ='null',-1,DATEPART(HOUR,convert(datetime,SO.RTN_LINE_MODFD_TS)))

left join 
DIM_DAY_HOUR_sql_IN1542 DH2
on  DH2.DATE_ID=iif(SO.RTN_LINE_CRE_TS IS NULL OR SO.RTN_LINE_CRE_TS ='NULL','01-01-1900',CONVERT(DATE,SO.RTN_LINE_CRE_TS ))
and DH2.hour_id=iif(SO.RTN_LINE_CRE_TS  is null or SO.RTN_LINE_CRE_TS ='null',-1,DATEPART(HOUR,convert(datetime,SO.RTN_LINE_CRE_TS)))
left join 
dim_day_sql_in1542 D
on iif(SO.RTN_LINE_CRE_DT is null or  SO.RTN_LINE_CRE_DT is not null ,'01-01-1990',format(convert(datetime,SO.RTN_LINE_CRE_DT),'yyyy-MM-dd'))=d.date_id 

select * from
BCMPWMT.RTN_ORDER_LINE
dim_prod_infa_IN1542
DIM_STS_LKP_infa_IN1542
dim_RSN_LKP_infa_IN1542
dim_day_infa_in1542
DIM_DAY_HOUR_infa_IN1542


DIM_STS_LKP_infa_IN1542


 select * from FACT_RTN_ORDER_LINE_infa_IN1542
---------------------------------------------- FACT_sales_order_line_IN1542  --------------------------------------------
2) FACT_sales_order_line_infa_IN1542  
CREATE TABLE FACT_sales_order_line_infa_IN1542  
(                               
SALES_ORDER_NUM	BIGINT   primary key         NOT NULL ,
SALES_ORDER_LINE_NUM	 INT       ,
TENANT_ORG_ID	INT               NOT NULL ,
SHIP_NODE_ORG_ID	varchar(50)   NOT NULL ,
GIFT_IND	int                   NOT NULL ,
ORDER_PLACED_DT	DATE              NOT NULL ,
ORDER_PLACED_TS	DATETIME          NOT NULL ,
SVC_NM	varchar(50)               NOT NULL ,
UNIT_PRICE	float                 NOT NULL ,
UNIT_COST	float                 NOT NULL ,
QTY	float                         NOT NULL ,
SHPD_QTY	varchar(50)           NOT NULL ,
SHIP_TO_ADDR_ID	varchar(50)       NOT NULL ,
WM_ITEM_NUM	varchar(50)           NOT NULL ,
UPC	varchar(50)                   NOT NULL ,
CATLG_ITEM_ID	varchar(50)       NOT NULL ,
PROD_OFFR_ID	varchar(50)       NOT NULL ,
RQ_CANCEL_TS	DATETIME          NOT NULL ,
RQ_SHIP_TS	DATETIME              NOT NULL ,
SLR_ORG_ID	INT                   NOT NULL ,
SHIP_TO_STORE_ORG_ID	INT       NOT NULL ,
ORDER_STS_ID	INT               NOT NULL ,
PROD_CLASS_ID	varchar(50)       NOT NULL ,
MAX_DAYS_TO_SHIP	varchar(50)   NOT NULL ,
EARLIEST_DLVR_TS	DATETIME      NOT NULL ,
ORIG_EXPC_DLVR_TS	DATETIME      NOT NULL ,
CARRIER_EXPC_DLVR_TS	DATETIME  NOT NULL ,
PROMO_ID	varchar(50)           NOT NULL ,
FULFMT_TYPE_ID	varchar(50)       NOT NULL ,
ORDER_LINE_TYPE_ID	INT           NOT NULL ,
LINE_TOT_AMT	float             NOT NULL ,
ORIG_SALES_ORDER_LINE_NUM	INT   NOT NULL ,
PERISHABLE_IND	int               NOT NULL ,
ITEM_CLASS_ID	INT               NOT NULL ,
CATLG_ITEM_KEY	INT               NOT NULL ,
PROD_OFFR_KEY	INT               NOT NULL ,
RQ_CANCEL_TS_KEY	INT           NOT NULL ,
RQ_SHIP_TS_KEY	INT               NOT NULL ,
ORDER_STS_KEY	INT               NOT NULL ,
EARLIEST_DLVR_TS_KEY	INT       NOT NULL ,
ORIG_EXPC_DLVR_TS_KEY	INT       NOT NULL ,
CARRIER_EXPC_DLVR_TS_KEY	INT   NOT NULL ,
SLR_ORG_KEY	INT                   NOT NULL ,
SHIP_TO_STORE_KEY	INT 		  NOT NULL )
drop table  FACT_sales_order_line_infa_IN1542  
select * into FACT_sales_order_line_infa_IN1542   from FACT_sales_order_line_sql_IN1542  

insert into FACT_RTN_ORDER_LINE_infa_IN1542 select * from FACT_RTN_ORDER_LINE_sql_IN1542
select * into FACT_RTN_ORDER_LINE_infa_IN1542    from   FACT_RTN_ORDER_LINE_sql_IN1542

drop table FACT_RTN_ORDER_LINE_infa_IN1542 
3)FACT_sales_order_adj_infa_IN1542




 -------------------------------------------------------------------------------------------------
4) DROP TABLE fact_sales_order_infa_IN1542
select * from fact_sales_order_infa_IN1542
select * from 
create table fact_sales_order_infa_IN1542(
SALES_ORDER_NUM	 BIGINT      PRIMARY KEY    ,

TENANT_ORG_ID	INT                    NOT NULL  ,
ORDER_REL_TS	DATETIME               NOT NULL  ,
ORDER_REL_DT	DATE                   NOT NULL  ,
ORDER_PLACED_TS	DATETIME               NOT NULL  ,
ORDER_PLACED_DT	DATE                   NOT NULL  ,
TOT_AMT	float                          NOT NULL  ,
TAX_AMT	float                          NOT NULL  ,
CURR_STS_ID	INT                        NOT NULL  ,
BILL_TO_ADDR_ID	varchar(50)            NOT NULL  ,
BILL_TO_CUST_ID	varchar(50)            NOT NULL  ,
CUST_CNTCT_ID	varchar(50)            NOT NULL  ,
GUEST_ORDER_IND	int                    NOT NULL  ,
CORP_ORDER_IND	int                    NOT NULL  ,
DEVICE_TYPE	varchar(50)                NOT NULL  ,
IP_ADDR	varchar(50)                    NOT NULL  ,
FRAUD_CHECK_REQD_IND	int            NOT NULL  ,
ORIG_SALES_ORDER_NUM	varchar(50)    NOT NULL  ,
HOLD_FLAG	int                        NOT NULL  ,
XCHNG_TYPE_ID	INT                    NOT NULL  ,
ORDER_TYPE_ID	INT                    NOT NULL  ,
WM_STORE_ORG_ID	INT                    NOT NULL  ,
ORDER_REL_TS_KEY	  INT                   ,
ORDER_REL_DT_KEY	  INT                   ,
ORDER_PLACED_TS_KEY	    INT                 ,
ORDER_PLACED_DT_KEY	     INT                ,
CURR_STS_ID_KEY	INT                      ,
BILL_TO_ADDR_ID_KEY	INT                  ,
BILL_TO_CUST_ID_KEY	INT                  ,
CUST_CNTCT_ID_KEY	INT                );


-------------------------------------------------------------------------------------------------
5) select * from FACT_ORDER_LINE_CHRG_infa_IN1542
DROP TABLE FACT_ORDER_LINE_CHRG_infa_IN1542

CREATE TABLE FACT_ORDER_LINE_CHRG_infa_IN1542(

SALES_ORDER_NUM	bigint  not null,
SALES_ORDER_LINE_NUM	INT not null,
TENANT_ORG_ID	INT not null,
CHARGE_CATEG_ID	INT not null,
CHRG_CATEG_MAP_ID	INT not null,
CHARGE_NM	VARCHAR(50) not null,
CHARGE_AMT	DECIMAL(19,6) not null,
CHRG_CRE_DT	DATETIME not null,
CHRG_QTY	INT not null,
CHRG_CRE_DT_KEY	INT not null,
charge_categ_key	INT not null);
SELECT * FROM FACT_sales_order_adj_SQL_IN1542