select * from 
IN1542.DIM_ORG_BUSINESS_UNIT_infa_IN1542 a left join 

IN1542.FACT_RTN_ORDER_LINE_infa_IN1542 b
on a.org_id=b.TENANT_ORG_ID
where  (b.TENANT_ORG_ID) is not null and rtn_qty<>0


select * from [BCMPWMT].[RSN_TYPE_LKP]
select * from [BCMPWMT].[RSN_LKP]
select * from [BCMPWMT].[RTN_RSN_LKP]
select * from [BCMPWMT].[RTN_RSN_LKP]



select rtn_rsn_cd
from [BCMPWMT].[RTN_ORDER_LINE] a left join [BCMPWMT].[RSN_LKP] b
on a.rtn_rsn_cd=b.RSN_ID
------------------------------------------------------------------------
select rtn_rsn_cd,count(*) from [BCMPWMT].[RTN_ORDER_LINE] group by rtn_rsn_cd order by rtn_rsn_cd asc

select rsn_id,count(*) from [BCMPWMT].[RSN_LKP] group by rsn_id order by rsn_id asc 
--------------------------
select DATEPART(QQ,RTN_LINE_MODFD_TS) AS QUARTER,DATEPART(MONTH,RTN_LINE_MODFD_TS) AS MONTH,
DATEPART(YEAR,RTN_LINE_MODFD_TS) AS YEAR,COUNT(*) as COUNT
from FACT_RTN_ORDER_LINE_SQL_IN1542 
GROUP BY DATEPART(QQ,RTN_LINE_MODFD_TS),DATEPART(MONTH,RTN_LINE_MODFD_TS),
DATEPART(YEAR,RTN_LINE_MODFD_TS)
ORDER BY YEAR

select * from  FACT_RTN_ORDER_LINE_SQL_IN1542
----------------------------------
select DATEPART(MONTH,RTN_LINE_CRE_TS) AS MONTH from FACT_RTN_ORDER_LINE_SQL_IN1542
GROUP BY DATEPART(MONTH,RTN_LINE_CRE_TS)
ORDER BY MONTH ASC
----------------------------
select COUNT(*),DATEPART(YEAR,RTN_LINE_CRE_TS) AS YEAR from FACT_RTN_ORDER_LINE_SQL_IN1542

GROUP BY DATEPART(YEAR,RTN_LINE_CRE_TS)
HAVING YEAR(RTN_LINE_CRE_TS) <> 1900
ORDER BY YEAR ASC

---------------------------------------------
SELECT distinct org_id FROM [BCMPWMT].[ORG_BUSINESS_UNIT]
where org_id = 4571

SELECT distinct tenant_org_id FROM��[BCMPWMT].[RTN_ORDER_LINE]
SELECT * FROM [BCMPWMT].[RSN_LKP]
WHERE ORG_NM = 'walmart.com'

select *��from��[BCMPWMT].[RTN_ORDER_LINE]

select sum(rtn_qty) from
[FACT_RTN_ORDER_LINE_SQL_IN1542]
where rtn_qty > 0

select a.tenant_org_id,b.org_nm from [BCMPWMT].[RTN_ORDER_LINE] a��left join [BCMPWMT].[ORG_BUSINESS_UNIT] b
on a.tenant_org_id = b.org_id

select count(*) from [BCMPWMT].[RTN_ORDER_LINE] a��right join [BCMPWMT].[ORG_BUSINESS_UNIT] b
on a.tenant_org_id = b.org_id


select a.RTN_ORDER_NUM ,a.tenant_org_id ,b.org_nm from [BCMPWMT].[RTN_ORDER_LINE] a��left join [BCMPWMT].[ORG_BUSINESS_UNIT] b
on a.tenant_org_id = b.org_id
--------------------------------------------
select a.tenant_org_id  from [BCMPWMT].[RTN_ORDER_LINE] a��left join [BCMPWMT].[ORG_BUSINESS_UNIT] b
on a.tenant_org_id = b.org_id

group by a.tenant_org_id
-------------------------

--------------------------------------
select count(*),a.tenant_org_id,b.org_nm from [BCMPWMT].[RTN_ORDER_LINE] a��right join [BCMPWMT].[ORG_BUSINESS_UNIT] b
on a.tenant_org_id = b.org_id
group by a.tenant_org_id,b.org_nm


select * from [BCMPWMT].[ORG_TYPE_LKP]
select * from [BCMPWMT].[ORG_BUSINESS_UNIT]

select a.rtn_order_num,b.org_nm,b.org_id,c.org_type_id,c.ORG_TYPE_NM from FACT_RTN_ORDER_LINE_SQL_IN1542 a left join DIM_ORG_BUSINESS_UNIT_SQL_IN1542 b
on b.org_id = a.tenant_org_id left join Dim_ORG_TYPE_LKP_SQL_IN1542 c on b.org_type_id = c.org_type_id
where rtn_order_num <> 'N/A'

select * from [dim_rpt_hrchy_SQL_IN1542]
select * from [dim_prod_SQL_IN1542]
------------------------------------
select * from FACT_RTN_ORDER_LINE_SQL_IN1542
select * from [dim_rpt_hrchy_INFA_IN1542]

select count(*) as count_a,div_id from FACT_RTN_ORDER_LINE_SQL_IN1542 a left join dim_rpt_hrchy_SQL_IN1542 b
on b.tenant_org_id = a.tenant_org_id
group by div_id

select count(*),SUPER_DEPT_ID from FACT_RTN_ORDER_LINE_SQL_IN1542 a left join dim_rpt_hrchy_SQL_IN1542 b
on a.CATLG_ITEM_ID = b.CATLG_ITEM_ID
group by SUPER_DEPT_ID


select * from
dim_rpt_hrchy_SQL_IN1542 a join dim_prod_rpt_hrchy_INFA_IN1542 b on a.RPT_HRCHY_ID=b.RPT_HRCHY_ID
join dim_prod_SQL_IN1542 c on a.catlg_item_id=c.catlg_item_id
----------------------------------------------------------------------------------------------------------------------------------------

select  year(b.date_id) as return_year,datepart(quarter,b.date_id) as return_quarter,month(b.date_id) as return_month,count(*) return_count

from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 a left join dim_day_sql_in1542 b
on a.rtn_line_cre_dt_key=b.day_key
group by year(b.date_id),datepart(quarter,b.date_id),month(b.date_id)

----------------------------------	Return by Month, Quarter & Year---------------
select  year(RTN_LINE_CRE_TS) as return_year,datepart(quarter,RTN_LINE_CRE_TS) as return_quarter,month(RTN_LINE_CRE_TS) as return_month,count(RTN_ORDER_NUM) return_count
from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 
group by year(RTN_LINE_CRE_TS),datepart(quarter,RTN_LINE_CRE_TS),month(RTN_LINE_CRE_TS)

-----------------------------------------------------------------------


select * from 
IN1542.FACT_RTN_ORDER_LINE_sql_IN1542




----------------------------------	Return by Month, Quarter & Year---------------
select  year(RTN_LINE_CRE_TS) as return_year,datepart(quarter,RTN_LINE_CRE_TS) as return_quarter,month(RTN_LINE_CRE_TS) as return_month,count(RTN_ORDER_NUM) return_count
from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 
group by year(RTN_LINE_CRE_TS),datepart(quarter,RTN_LINE_CRE_TS),month(RTN_LINE_CRE_TS)
----------------------------------Return by Organization Business Unit-------------------------------------------
select a.tenant_org_id, c.ORG_NM  
from IN1542.FACT_sales_order_line_sql_IN1542  a
left join  IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 b
on a.[SALES_ORDER_NUM] = b.[SALES_ORDER_NUM] and a.[SALES_ORDER_LINE_NUM] = b.[SALES_ORDER_LINE_NUM]
�left join
IN1542.DIM_ORG_BUSINESS_UNIT_SQL_IN1542 c
on cast(a.tenant_org_id as varchar) = cast(c.SRC_ORG_CD as varchar)
group by a.tenant_org_id,c.ORG_NM 

select * from FACT_RTN_ORDER_LINE_sql_IN1542 b
 
select * from DIM_ORG_BUSINESS_UNIT_sql_IN1542
-------------------------------------------------
select count(b.RTN_ORDER_NUM),a.tenant_org_id, c.ORG_NM   from FACT_sales_order_line_sql_IN1542  a
left join  FACT_RTN_ORDER_LINE_sql_IN1542 b
on a.[SALES_ORDER_NUM] = b.[SALES_ORDER_NUM]
left join DIM_ORG_BUSINESS_UNIT_sql_IN1542 c
on b.RCV_STORE_ORG_CD = c.SRC_ORG_CD
group by a.tenant_org_id,c.ORG_NM,b.RTN_ORDER_NUM
order by b.RTN_ORDER_NUM desc
----------------------------Return by Product Hierarchy------------
select count(DIV_NM)Count_DIV_NM ,
count(d.[SUPER_DEPT_NM])Count_SUPER_DEPT_NM ,
count(d.[DEPT_NM])Count_DEPT_NM , 
count(d.[CATEG_NM])Count_CATEG_NM,
count(d.[SUB_CATEG_NM])Count_SUB_CATEG_NM
from IN1542.FACT_sales_order_line_sql_IN1542  a
left join  IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 b
on a.[SALES_ORDER_NUM] = b.[SALES_ORDER_NUM] and a.[SALES_ORDER_LINE_NUM] = b.[SALES_ORDER_LINE_NUM]
left join IN1542. Dim_prod_rpt_hrchy_SQL_IN1542 c
on b.[CATLG_ITEM_ID] = c.[CATLG_ITEM_ID]
left join IN1542.DIM_rpt_hrchy_SQL_IN1542 d
on c.[RPT_HRCHY_ID] = d.[RPT_HRCHY_ID]
left join IN1542.DIM_prod_SQL_IN1542 e
on b.[CATLG_ITEM_ID] = e.[CATLG_ITEM_ID]
--left join dim_day_sql_in1542 f
--on a.rtn_order_key = f.DAY_KEY
--where year(f.DATE_ID) in ('2016', '2017')
group by d.[DIV_NM], d.[SUPER_DEPT_NM], d.[DEPT_NM] , d.[CATEG_NM], d.[SUB_CATEG_NM]

order by Count_DIV_NM  desc
------------------------Return Reason Analysis (Top 20)-----------------------------

select count(DIV_NM)Count_DIV_NM ,
count(d.[SUPER_DEPT_NM])Count_SUPER_DEPT_NM ,
count(d.[DEPT_NM])Count_DEPT_NM , 
count(d.[CATEG_NM])Count_CATEG_NM,
count(d.[SUB_CATEG_NM])Count_SUB_CATEG_NM
from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 a
left join IN1542.FACT_sales_order_line_sql_IN1542 b
on a.[SALES_ORDER_NUM] = b.[SALES_ORDER_NUM] and a.[SALES_ORDER_LINE_NUM] = b.[SALES_ORDER_LINE_NUM]
left join IN1542. Dim_prod_rpt_hrchy_SQL_IN1542 c
on b.[CATLG_ITEM_ID] = c.[CATLG_ITEM_ID]
left join IN1542.DIM_rpt_hrchy_SQL_IN1542 d
on c.[RPT_HRCHY_ID] = d.[RPT_HRCHY_ID]
left join IN1542.DIM_prod_SQL_IN1542 e
on b.[CATLG_ITEM_ID] = e.[CATLG_ITEM_ID]
--left join dim_day_sql_in1542 f
--on a.rtn_order_key = f.DAY_KEY
--where year(f.DATE_ID) in ('2016', '2017')
group by d.[DIV_NM], d.[SUPER_DEPT_NM], d.[DEPT_NM] , d.[CATEG_NM], d.[SUB_CATEG_NM]

order by Count_DIV_NM  desc
-----------------------------------------

select [RSN_DESC]  from
(SELECT  b.[RSN_DESC],count(a.[RTN_RSN_CD]) [No of Returns],rank() over (ORDER BY count(a.[RTN_RSN_CD])) AS G
from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 a
join  IN1542.DIM_RSN_LKP_sql_IN1542 b
on a.[RTN_RSN_CD]= cast(b.[RSN_ID] as varchar)
group by b.[RSN_DESC],a.[RTN_RSN_CD])k
where G<=20








SELECT * FROM 
[BCMPWMT].[RTN_ORDER_LINE] a left join  [BCMPWMT].[RSN_LKP] b
on a.[RTN_RSN_CD]= b.[RSN_ID] 


--------------------------------------------------------------------
select d.[DIV_NM],d.[SUPER_DEPT_NM], d.[DEPT_NM] , d.[CATEG_NM], d.[SUB_CATEG_NM], sum(a.[LINE_TOT_AMT]) [ADJUSMENT_AMT]
from IN1542.FACT_sales_order_line_sql_IN1542 a
left join IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 b
on a.[SALES_ORDER_NUM] = b.[SALES_ORDER_NUM] and a.[SALES_ORDER_LINE_NUM] = b.[SALES_ORDER_LINE_NUM]
left join IN1542. Dim_prod_rpt_hrchy_SQL_IN1542 c
on b.[CATLG_ITEM_ID] = c.[CATLG_ITEM_ID]
left join IN1542.DIM_rpt_hrchy_SQL_IN1542 d
on c.[RPT_HRCHY_ID] = d.[RPT_HRCHY_ID]
left join IN1542.DIM_prod_SQL_IN1542 e
on b.[CATLG_ITEM_ID] = e.[CATLG_ITEM_ID]
--left join dim_day_sql_in1542 f
--on a.rtn_order_key = f.DAY_KEY
--where year(f.DATE_ID) in ('2016', '2017')
group by d.[DIV_NM], d.[SUPER_DEPT_NM], d.[DEPT_NM] , d.[CATEG_NM], d.[SUB_CATEG_NM]
----------------------------------------------------------------------------------




















select * from 
IN1542.FACT_RTN_ORDER_LINE_sql_IN1542

-----------------------------
select  year(b.RTN_LINE_MODFD_TS) as return_year,datepart(quarter,b.RTN_LINE_MODFD_TS) as return_quarter,month(.RTN_LINE_MODFD_TS) as return_month,count(*) return_count
from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 a left join dim_day_sql_in1542 b
on a.rtn_line_cre_dt_key=b.day_key
where year(b.date_id) is not  null
group by year(b.date_id),datepart(quarter,b.date_id),month(b.date_id)
------------------------------------------------------------------------------------------------------------------------------------------------------------
 
select year(b.date_id) as return_year,datepart(quarter,b.date_id) as return_quarter,month(b.date_id) as return_month,count(*) return_count

from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 a left join dim_day_sql_in1542 b
on a.rtn_line_cre_dt_key=b.day_key

where 
 RTN_QTY<>0

 group by year(b.date_id),datepart(quarter,b.date_id),month(b.date_id)


 --------------------------------------------------------------------------------------------------------------------------------------------------------

































select * from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542 

select * from IN1542.dim_day_sql_in1542