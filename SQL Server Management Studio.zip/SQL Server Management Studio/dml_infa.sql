DML

UPDATE DIM_CUST_CNTCT_infa_IN1542 SET DIM_CUST_CNTCT_infa_IN1542 .[CUST_PHONE_KEY]= 
DIM_CUST_PHONE_infa_IN1542.[CUST_PHONE_KEY] 
 FROM
DIM_CUST_CNTCT_infa_IN1542 JOIN DIM_CUST_PHONE_infa_IN1542 ON
 CONVERT(VARCHAR(50),DIM_CUST_CNTCT_infa_IN1542.PHONE_ID)=CONVERT(VARCHAR(50),
DIM_CUST_PHONE_infa_IN1542.PHONE_ID)


 UPDATE DIM_CUST_CNTCT_infa_IN1542 SET DIM_CUST_CNTCT_infa_IN1542 .[Cust_email_key ]= 
 DIM_CUST_EMAIL_infa_IN1542.[Cust_email_key] 
 FROM
DIM_CUST_CNTCT_infa_IN1542 JOIN  DIM_CUST_EMAIL_infa_IN1542 ON
 CONVERT(VARCHAR(50),DIM_CUST_CNTCT_infa_IN1542.EMAIL_ID )=CONVERT(VARCHAR(50),
 DIM_CUST_EMAIL_infa_IN1542.EMAIL_ID )


 UPDATE DIM_CUST_CNTCT_infa_IN1542 SET DIM_CUST_CNTCT_infa_IN1542 .[ addr_zone_id_key   ]= 
 dim_cust_addr_zone_infa_IN1542.[addr_zone_id_key  ] 
 FROM
DIM_CUST_CNTCT_infa_IN1542 JOIN   dim_cust_addr_zone_infa_IN1542 ON
 CONVERT(VARCHAR(50),DIM_CUST_CNTCT_infa_IN1542.ADDR_ZONE_ID  )=CONVERT(VARCHAR(50),
 dim_cust_addr_zone_infa_IN1542.ADDR_ZONE_ID  )


 UPDATE DIM_CUST_CNTCT_infa_IN1542 SET DIM_CUST_CNTCT_infa_IN1542 .[ cust_acct_key  ]= 
  dim_CUST_ACCT_infa_IN1542.[cust_acct_key] 
 FROM
DIM_CUST_CNTCT_infa_IN1542 JOIN     dim_CUST_ACCT_infa_IN1542 ON
 CONVERT(VARCHAR(50),DIM_CUST_CNTCT_infa_IN1542.ACCT_ID )=CONVERT(VARCHAR(50),
  dim_CUST_ACCT_infa_IN1542.ACCT_ID  )

  UPDATE DIM_CUST_CNTCT_infa_IN1542
  SET [ cust_acct_key  ]=ISNULL([ cust_acct_key  ],101),
  [ addr_zone_id_key  ] =ISNULL([ addr_zone_id_key  ],101),
  [Cust_email_key]=ISNULL([Cust_email_key],101),
  [CUST_PHONE_KEY]=ISNULL([CUST_PHONE_KEY],101)

  -----------------------------------------------------------------------------------------
  UPDATE  Dim_OFFR_infa_IN1542 SET PROD_KEY=P.PROD_KEY
 FROM Dim_OFFR_infa_IN1542 D LEFT JOIN dim_prod_infa_IN1542 P ON
 D.CATLG_ITEM_ID=P.CATLG_ITEM_ID
 UPDATE  Dim_OFFR_infa_IN1542  SET [prod_key] =ISNULL([prod_key],101)
 SELECT * FROM Dim_OFFR_infa_IN1542
 -----------------------------------------------------------------------------------------
 DML_FACT
 UPDATE Fact_sales_order_INFA_IN1542 SET ORDER_REL_TS_KEY= DH.day_hour_key
   FROM Fact_sales_order_INFA_IN1542 F JOIN DIM_DAY_HOUR_INFA_IN1542 DH ON
   CONVERT(DATE,F.ORDER_REL_TS)=DH.DATE_ID
   AND
   DH.Hour_id = DATEPART(HOUR,F.ORDER_REL_TS)
   --------------------------------------------------------   
   UPDATE Fact_sales_order_INFA_IN1542 SET ORDER_PLACED_TS_KEY= DH.day_hour_key  
   FROM Fact_sales_order_INFA_IN1542 F JOIN DIM_DAY_HOUR_INFA_IN1542 DH ON
   CONVERT(DATE,F.ORDER_PLACED_TS)=DH.DATE_ID
   AND
   DH.Hour_id = DATEPART(HOUR,F.ORDER_PLACED_TS)
   --------------------------------------------------------
   UPDATE Fact_sales_order_INFA_IN1542 SET [ORDER_REL_DT_KEY]= DH.DAY_KEY
   FROM Fact_sales_order_INFA_IN1542 F JOIN dim_day_INFA_IN1542 DH ON
   CONVERT(DATE,F.[ORDER_REL_DT])=DH.DATE_ID
   ----------------------------------------------------------
   UPDATE Fact_sales_order_INFA_IN1542 SET [ORDER_PLACED_DT_KEY]= DH.DAY_KEY
   FROM Fact_sales_order_INFA_IN1542 F JOIN dim_day_INFA_IN1542 DH ON
   CONVERT(DATE,F.[ORDER_PLACED_DT])=DH.DATE_ID

    SELECT * FROM Fact_sales_order_INFA_IN1542

