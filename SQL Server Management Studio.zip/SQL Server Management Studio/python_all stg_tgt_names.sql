
select * from STG_DIM_CHARGE_CATEG_PYTHON_IN1542
select * from DIM_CHARGE_CATEG_PYTHON_IN1542
--------------------------------------------------------
select * from  stg_DIM_CUST_python_IN1542

select * from  DIM_CUST_python_IN1542
WHERE CUST_ID=51428720

truncate table  stg_DIM_CUST_python_IN1542
truncate table  DIM_CUST_python_IN1542

UPDATE STG_DIM_CUST_python_IN1542 
SET salute='M'
WHERE CUST_ID=51428720
-----------------------------------------------------------------

select * from stg_DIM_CUST_EMAIL_python_IN1542
select * from DIM_CUST_EMAIL_python_IN1542
-----------------------------------------------------------
select * from stg_Dim_RSN_TYPE_LKP_python_in1542
select * from Dim_RSN_TYPE_LKP_python_in1542
------------------------------------------------------
select * from stg_DIM_STS_LKP_python_IN1542
select * from DIM_STS_LKP_python_IN1542
---------------------------------------
select * from stg_Dim_FULFMT_TYPE_LKP_python_IN1542
select * from Dim_FULFMT_TYPE_LKP_python_IN1542
----------------------------------------
select * from stg_Dim_ORDER_STS_MASTER_LKP_python1_IN1542
select * from Dim_ORDER_STS_MASTER_LKP_python1_IN1542
------------------------------------------------------------
select * from stg_dim_RSN_LKP_python_IN1542
select * from dim_RSN_LKP_python_IN1542

------------------------------------------------
select * from stg_dim_CUST_ACCT_python_IN1542
select * from dim_CUST_ACCT_python_IN1542

select * from stg_dim_CUST_ACCT_python_IN1542 
select * from dim_CUST_ACCT_python_IN1542 
where acct_id=15038708


update stg_dim_CUST_ACCT_python_IN1542 
set email='harithaanduri@1695'
where acct_id=15038708

truncate table stg_dim_CUST_ACCT_python_IN1542 
truncate table dim_CUST_ACCT_python_IN1542 
-------------------------------------------------------
 
  select upd_ts from [BCMPWMT].[CUST_ADDR]
 select * from stg_dim_cust_address_python_IN1542 
   select * from dim_cust_address_python_IN1542
  select * from dim_cust_address_python_IN1542 where addr_id=2770272514

 update stg_dim_cust_address_python_IN1542
set town='Kadapa'
where addr_id=2770272514

 truncate table stg_dim_cust_address_python_IN1542
  truncate table dim_cust_address_python_IN1542
  -------------------------------------------------------------------------------------

select * from stg_dim_cust_addr_zone_python_IN1542
select * from dim_cust_addr_zone_python_IN1542
-------	-------------------------------------------------------------------------------

select * from stg_dim_cust_addr1_python_IN1542 where addr_id=2837303787
select * from dim_cust_addr1_python_IN1542
------------------------------------------------------------------------------------
select data_src_id from [BCMPWMT].[CUST_PHONE]
select * from DIM_CUST_PHONE_python_IN1542
select * from  stg_DIM_CUST_PHONE_python_IN1542
------------------------------------------------
select *from [BCMPWMT].[ORG_BUSINESS_UNIT]

select * from stg_DIM_ORG_BUSINESS_UNIT_python_IN1542
select * from DIM_ORG_BUSINESS_UNIT_python_IN1542 where org_id=88938

  truncate table stg_DIM_ORG_BUSINESS_UNIT_python_IN1542
    truncate table DIM_ORG_BUSINESS_UNIT_python_IN1542
---------------------------------------------------------------------



------------------------------------------------------	
select * from stg_dim_prod_python_IN1542
select * from dim_prod_python_IN1542

----------------------------------

select * from  str_dim_rpt_hrchy_python_IN1542
select * from  dim_rpt_hrchy_python_IN1542
------------------------------------------------------

select * from
[BCMPWMT].[ORG_TYPE_LKP]
select * from stg_Dim_ORG_TYPE_LKP_python_IN1542
select * from Dim_ORG_TYPE_LKP_python_IN1542
select * from stg_DIM_STS_LKP_python_IN1542 
------------------
select  * from  [BCMPWMT].[OFFR]

select * from stg_Dim_OFFR_python_IN1542
select * from Dim_OFFR_python_IN1542
--------------------------------------------------------------
select * from DIM_CHARGE_CATEG_PYTHON_IN1542
--------------------------------------------------------------------------
select * from [BCMPWMT].[ORDER_LINE_CHRG]
