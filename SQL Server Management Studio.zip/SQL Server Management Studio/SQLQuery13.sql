select * from IN1542.FACT_RTN_ORDER_LINE_sql_IN1542
order by RTN_ORDER_NUM

select * from [BCMPWMT].[RTN_ORDER_LINE]
order by RTN_ORDER_NUM