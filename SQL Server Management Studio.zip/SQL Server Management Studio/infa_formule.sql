length         LENGTH(Column_Name) 
--------------substr-------------------------
Remove First Two Characters     SUBSTR('abcdef',3)
 Extract Third and Fourth Character  SUBSTR('abcdef',3,2)
 to extract last 3 characters from the string.  SUBSTR('abcdef',-3,3)
 ---------------------------lpad/rpad---------------------
Pads Marks With 0's and the length of the string is always uniformLPAD       ----(Marks, 3, '0') ---10-->010
RPAD (Column, 5, '-�)  		Test-------->Test-
----------------rtrim/ltrim-------------------
RTRIM (ITEM) 'haritha '--'haritha'
RTRIM (ITEM,'10') --- 0510 -    05
-----------------concat------------------
Concatenation Operator - ||
---------------------------------------------
last date of the month
LAST_DAY( ORDER_DATE ) 
Apr 1 1998 12:00:00AM   --------Apr 30 1998 12:00:00AM
---------------
ADD_TO_DATE(ADD_TO_DATE(LAST_DAY( ORDER_DATE ),'MM',-1),'DD',1)
 first day of the month for each date in the
 ----------------------------
  GET_DATE_PART ( DATE_SHIPPED, 'D' )

