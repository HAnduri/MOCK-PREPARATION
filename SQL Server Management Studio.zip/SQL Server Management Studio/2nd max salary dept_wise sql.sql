e_id dept_name emp_name salary---table name  dim_emp





select top 2 emp_name ,salary ,

from dim_emp 
order by salary 


select  e_id, 
   emp_name, 
    salary 
FROM   
    (
        SELECT 
            e_id, 
            emp_NAME, 
            salary, 
            Dense_rank()OVER (partition BY departmentid 
                          ORDER BY salary DESC) AS Rank, 
             Count(1)OVER(partition BY departmentid) AS cnt 
        FROM   
            employees
    )t 
WHERE  
    t.rank = 2 
    OR ( t.rank = 1 
         AND cnt = 1 ) e_id dept_name emp_name salary---table name  dim_emp




create table employee_d(
em_id int,
dep_name varchar(30),
emp_name varchar(30),
salary money

)
insert into employee_d 
values(1,'math','haritha',22000),
(2,'phy','kalai',27000),
(3,'math','sravanth',40000),
(4,'phy','santhosh',70000),
(5,'phy','mahesh',10000),
(6,'che','sai',12000),
(7,'che','ashwini',20000)
select * from employee_d
drop table employee_d

select t.em_id, t.emp_name,t.salary 
FROM   
    (
        SELECT 
           em_id, 
            emp_NAME, 
            salary, 
            Dense_rank() OVER (partition BY dep_name 
                          ORDER BY salary DESC) AS Rank
            
        FROM   
            employee_d 
    )t 
WHERE  
    t.rank = 2 
  

select dep_name,max(salary) from employee_d  a
where salary <>(select max(salary) from employee_d b  where a.dep_name =b.dep_name)
group by dep_name